<?php
/** Research overview. */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$page_title       = 'Research';
$page_description = 'Research domains, active focus areas and the translational pipeline at Neurobridge Research — neuroscience, bioinformatics, biotechnology, molecular biology, microbiology, pharmacology and chemistry.';

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Research';
$ph_lead   = $RESEARCH['intro'];
$ph_crumbs = [['label' => 'Research']];
require APP_ROOT . '/includes/partials/page-header.php';
?>

<!-- Domains --------------------------------------------------------------->
<section class="section">
  <div class="container">
    <div class="section-head">
      <span class="kicker">Core disciplines</span>
      <h2>Seven research domains</h2>
      <p>Each domain has a named faculty lead, a standing methods reference, and at least one open dataset or repository released to the community.</p>
    </div>

    <div class="grid grid-auto-lg">
      <?php foreach ($RESEARCH['domains'] as $domain): ?>
        <article class="card domain-card" id="<?= e($domain['slug']) ?>">
          <div class="icon-badge"><?= icon($domain['icon']) ?></div>
          <h3><?= e($domain['title']) ?></h3>
          <p><?= e($domain['summary']) ?></p>
          <ul>
            <?php foreach ($domain['topics'] as $topic): ?>
              <li><?= e($topic) ?></li>
            <?php endforeach; ?>
          </ul>
          <div class="domain-meta"><?= e((string) $domain['projects']) ?> active &amp; completed projects</div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Focus areas ----------------------------------------------------------->
<section class="section section--surface">
  <div class="container">
    <div class="section-head">
      <span class="kicker">Future Collaborative Research Portfolio</span>
      <h2>Planned Research Projects</h2>
      <p>These are planned future research areas intended for international collaboration. Specific research questions, hypotheses, methodologies, datasets, and analytical plans will be developed when individual projects are formally initiated.</p>
    </div>

    <div class="grid grid-4">
      <?php foreach ($RESEARCH['focus_areas'] as $area): ?>
        <article class="card">
          <div class="badge-group" style="margin-bottom:14px;">
            <span class="badge <?= $area['status'] === 'Active' ? 'badge--ok' : 'badge--outline' ?>"><?= e($area['status']) ?></span>
          </div>
          <h3><?= e($area['title']) ?></h3>
          
          <div class="tag-row">

          </div>
        </article>
      <?php endforeach; ?>
    </div>

    <div class="section-head">
      <br>
      <h2>Confidentiality & Intellectual Property Notice</h2>
      <p>The titles listed here represent broad planned research areas only and do not disclose the complete research concepts, hypotheses, protocols, datasets, analytical strategies, or unpublished findings of future projects. Detailed project information will be shared with approved collaborators as appropriate.</p>
    </div>
  </div>
</section>

<!-- Pipeline -------------------------------------------------------------->
<section class="section">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">How a project runs</span>
        <h2>From question to release in five stages</h2>
        <p>Every project follows the same sequence, and no stage is skipped because a result looks promising. The written protocol comes first; the analysis plan is fixed before the data are unblinded.</p>
        <div class="note-box mt-3">
          <strong>Internal review is mandatory</strong>
          No manuscript leaves the group without two internal reviews — one methodological and one from a member outside the project team.
        </div>
      </div>

      <ol class="steps">
        <?php foreach ($RESEARCH['pipeline'] as $step): ?>
          <li class="step">
            <span class="step-num"><?= e($step['step']) ?></span>
            <div>
              <h3><?= e($step['title']) ?></h3>
              <p><?= e($step['text']) ?></p>
            </div>
          </li>
        <?php endforeach; ?>
      </ol>
    </div>
  </div>
</section>

<!-- Facilities ------------------------------------------------------------>
<section class="section section--tint">
  <div class="container">
    <div class="section-head">
      <span class="kicker">Facilities &amp; access</span>
      <h2>What our teams work with</h2>
      <p>Instrumentation is accessed through partner departments and institutes under standing memoranda of understanding. Computational infrastructure is maintained in-house.</p>
    </div>

    <div class="grid grid-4">
      <?php foreach ($RESEARCH['facilities'] as $f): ?>
        <div class="card card--flat">
          <h3 style="font-size:1rem;"><?= e($f['title']) ?></h3>
          <p><?= e($f['text']) ?></p>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="btn-row mt-4">
      <a class="btn btn-primary" href="<?= e(url('/publications/')) ?>">See what we have published</a>
      <a class="btn btn-outline" href="<?= e(url('/resources/')) ?>">Open datasets &amp; code</a>
    </div>
  </div>
</section>

<section class="cta-band">
  <div class="container">
    <div>
      <h2>Interested in collaborating?</h2>
      <p>We work with universities, hospitals and laboratories on joint studies, shared instrumentation and co-supervision of research fellows.</p>
    </div>
    <div class="btn-row">
      <a class="btn btn-light" href="<?= e(url('/contact/')) ?>">Propose a collaboration</a>
      <a class="btn btn-ghost-light" href="<?= e(url('/team/collaborators/')) ?>">Current partners</a>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
