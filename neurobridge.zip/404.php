<?php
/** 404 page. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

http_response_code(404);

$page_title       = 'Page not found';
$page_description = 'The page you requested could not be found.';

require APP_ROOT . '/includes/header.php';
?>

<section class="section">
  <div class="container container--narrow center">
    <span class="kicker">Error 404</span>
    <h1>We could not find that page</h1>
    <p class="lead">The address may have changed, or the page may have been moved. The links below cover most of what is on this site.</p>

    <div class="btn-row" style="justify-content:center;margin-top:28px;">
      <a class="btn btn-primary" href="<?= e(url('/')) ?>">Back to home</a>
      <a class="btn btn-outline" href="<?= e(url('/contact/')) ?>">Report a broken link</a>
    </div>

    <ul class="pill-list" style="justify-content:center;margin-top:40px;">
      <li><a href="<?= e(url('/research/')) ?>">Research</a></li>
      <li><a href="<?= e(url('/team/')) ?>">Team</a></li>
      <li><a href="<?= e(url('/publications/')) ?>">Publications</a></li>
      <li><a href="<?= e(url('/events/')) ?>">Events</a></li>
      <li><a href="<?= e(url('/resources/')) ?>">Resources</a></li>
      <li><a href="<?= e(url('/join/')) ?>">Join us</a></li>
    </ul>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
