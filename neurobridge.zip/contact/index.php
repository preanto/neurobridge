<?php
/** Contact details and general enquiry form. */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$page_title       = 'Contact';
$page_description = 'Contact Neurobridge Research — lab address in Dhaka, e-mail, phone, and an enquiry form for collaboration, data requests, media and training.';

$subjects = [
    'General enquiry',
    'Research collaboration',
    'Data or code request',
    'Training &amp; workshops',
    'Media &amp; communications',
    'Student application question',
];
$subjectValues = array_map(static fn ($s) => html_entity_decode($s, ENT_QUOTES, 'UTF-8'), $subjects);

$errors  = [];
$success = false;
$old     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = [
        'name'         => post('name'),
        'email'        => post('email'),
        'organisation' => post('organisation'),
        'subject'      => post('subject'),
        'message'      => post('message'),
    ];

    if (!csrf_valid($_POST['_token'] ?? null)) {
        $errors[] = 'Your session expired. Please send the message again.';
    }
    if (post('website') !== '') {
        $errors[] = 'This submission was rejected as automated.';
    }
    if ($old['name'] === '')                      { $errors['name']    = 'Please enter your name.'; }
    if (!valid_email($old['email']))              { $errors['email']   = 'Please enter a valid e-mail address.'; }
    if (!in_array($old['subject'], $subjectValues, true)) { $errors['subject'] = 'Please choose a subject.'; }
    if (mb_strlen($old['message']) < 20)          { $errors['message'] = 'Please write at least a couple of sentences.'; }
    if (empty($_POST['consent']))                 { $errors['consent'] = 'Please confirm that we may store your message.'; }

    if (!$errors) {
        store_submission('enquiry', $old);
        $success = true;
        $old     = [];
    }
}

$val = static fn (string $key): string => e($old[$key] ?? '');

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Contact us';
$ph_lead   = 'For collaboration proposals, data requests, training enquiries or anything else — write to us and a named person will answer, usually within three working days.';
$ph_crumbs = [['label' => 'Contact']];
require APP_ROOT . '/includes/partials/page-header.php';
?>

<section class="section">
  <div class="container">
    <div class="split">

      <!-- Form ------------------------------------------------------------>
      <div>
        <span class="kicker">Enquiry form</span>
        <h2>Send us a message</h2>

        <?php if ($success): ?>
          <div class="alert alert--ok" role="status" style="margin-top:20px;">
            <strong>Message sent.</strong>
            Thank you — we have your message and will reply to the address you gave, usually within three working days.
          </div>
        <?php endif; ?>

        <?php if ($errors): ?>
          <div class="alert alert--error" role="alert" style="margin-top:20px;">
            <strong>Your message was not sent.</strong>
            Please correct the following:
            <ul>
              <?php foreach ($errors as $message): ?>
                <li><?= e($message) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form class="form-card" method="post" action="<?= e(url('/contact/')) ?>" novalidate style="margin-top:20px;">
          <?= csrf_field() ?>
          <div class="honeypot" aria-hidden="true">
            <label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
          </div>

          <div class="form-grid">
            <label class="field">
              <span class="field-label">Your name <span class="required">*</span></span>
              <input class="input <?= isset($errors['name']) ? 'field-error' : '' ?>" type="text" name="name" value="<?= $val('name') ?>" required>
              <?php if (isset($errors['name'])): ?><span class="error-text"><?= e($errors['name']) ?></span><?php endif; ?>
            </label>

            <label class="field">
              <span class="field-label">E-mail <span class="required">*</span></span>
              <input class="input <?= isset($errors['email']) ? 'field-error' : '' ?>" type="email" name="email" value="<?= $val('email') ?>" required>
              <?php if (isset($errors['email'])): ?><span class="error-text"><?= e($errors['email']) ?></span><?php endif; ?>
            </label>

            <label class="field">
              <span class="field-label">Organisation (optional)</span>
              <input class="input" type="text" name="organisation" value="<?= $val('organisation') ?>">
            </label>

            <label class="field">
              <span class="field-label">Subject <span class="required">*</span></span>
              <select class="select <?= isset($errors['subject']) ? 'field-error' : '' ?>" name="subject" required>
                <option value="">Select…</option>
                <?php foreach ($subjectValues as $s): ?>
                  <option value="<?= e($s) ?>"<?= ($old['subject'] ?? '') === $s ? ' selected' : '' ?>><?= e($s) ?></option>
                <?php endforeach; ?>
              </select>
              <?php if (isset($errors['subject'])): ?><span class="error-text"><?= e($errors['subject']) ?></span><?php endif; ?>
            </label>

            <label class="field field--full">
              <span class="field-label">Message <span class="required">*</span></span>
              <textarea class="textarea <?= isset($errors['message']) ? 'field-error' : '' ?>" name="message" required><?= $val('message') ?></textarea>
              <?php if (isset($errors['message'])): ?><span class="error-text"><?= e($errors['message']) ?></span><?php endif; ?>
            </label>

            <div class="field field--full">
              <label class="check-row">
                <input type="checkbox" name="consent" value="1">
                <span>I consent to Neurobridge Research storing this message so that it can be answered. <span class="required">*</span></span>
              </label>
              <?php if (isset($errors['consent'])): ?><span class="error-text"><?= e($errors['consent']) ?></span><?php endif; ?>
            </div>
          </div>

          <button class="btn btn-primary" type="submit">Send message</button>
        </form>
      </div>

      <!-- Details --------------------------------------------------------- -->
      <div>
        <span class="kicker">Details</span>
        <h2>Where to find us</h2>

        <ul class="info-list">
          <li>
            <span class="label">Address</span>
            <span class="value">
              <?= e($SITE['contact']['address']['line1']) ?><br>
              <?= e($SITE['contact']['address']['line2']) ?><br>
              <?= e($SITE['contact']['address']['city']) ?>, <?= e($SITE['contact']['address']['country']) ?>
            </span>
          </li>
          <li>
            <span class="label">General</span>
            <span class="value"><a href="mailto:<?= e($SITE['contact']['email']) ?>"><?= e($SITE['contact']['email']) ?></a></span>
          </li>
          <li>
            <span class="label">Applications</span>
            <span class="value"><a href="mailto:<?= e($SITE['contact']['admissions']) ?>"><?= e($SITE['contact']['admissions']) ?></a></span>
          </li>
          <li>
            <span class="label">Media</span>
            <span class="value"><a href="mailto:<?= e($SITE['contact']['press']) ?>"><?= e($SITE['contact']['press']) ?></a></span>
          </li>
          <li>
            <span class="label">Phone</span>
            <span class="value"><a href="tel:<?= e(str_replace(' ', '', $SITE['contact']['phone'])) ?>"><?= e($SITE['contact']['phone']) ?></a></span>
          </li>
          <li>
            <span class="label">Hours</span>
            <span class="value"><?= e($SITE['contact']['hours']) ?></span>
          </li>
        </ul>

        <div class="map-placeholder" style="margin-top:26px;">
          <div class="inner">
            <?= icon('pin') ?>
            <h3 style="font-size:1rem;margin:.5rem 0 .3rem;"><?= e($SITE['contact']['address']['line2']) ?></h3>
            <p><?= e($SITE['contact']['address']['city']) ?>, <?= e($SITE['contact']['address']['country']) ?></p>
            <a class="btn btn-outline btn-sm" href="https://www.google.com/maps/search/?api=1&amp;query=<?= e(urlencode($SITE['contact']['map_query'])) ?>" target="_blank" rel="noopener">Open in Maps</a>
            <p class="muted" style="font-size:.72rem;margin:14px 0 0;">Replace this block with an embedded map iframe in <code>contact/index.php</code>.</p>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="grid grid-3">
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('handshake') ?></div>
        <h3>Collaboration proposals</h3>
        <p>Tell us the question, what you already hold (cohort, instrument, dataset) and what you need. We will reply with what we can realistically contribute and by when.</p>
      </div>
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('database') ?></div>
        <h3>Data &amp; code requests</h3>
        <p>Most material is already public. For restricted clinical data, include the intended analysis and your institutional ethics approval.</p>
        <div class="card-foot"><a class="arrow-link" href="<?= e(url('/resources/datasets/')) ?>">Browse datasets</a></div>
      </div>
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('users') ?></div>
        <h3>Workshops at your institution</h3>
        <p>We deliver the methodology and bioinformatics bootcamps at partner campuses, usually free of charge where a department hosts the venue.</p>
        <div class="card-foot"><a class="arrow-link" href="<?= e(url('/events/')) ?>">See past events</a></div>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
