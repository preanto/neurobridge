<?php
/** Publications overview. */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$page_title       = 'Publications';
$page_description = 'Journal articles and peer-reviewed conference papers from Neurobridge Research, filterable by year and indexing database.';

$journal    = $PUBLICATIONS['journal'];
$conference = $PUBLICATIONS['conference'];
$all        = array_merge($journal, $conference);

usort($all, static fn ($a, $b) => $b['year'] <=> $a['year']);
$recent = array_slice($all, 0, 6);

$years   = column_options($all, 'year', true);
$q1Count = count(array_filter($journal, fn ($p) => in_array('Q1', $p['indexes'], true)));
$oaCount = count(array_filter($all, fn ($p) => !empty($p['open']) || in_array('Open Access', $p['indexes'], true)));

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Publications';
$ph_lead   = 'Everything the group has published, split into journal articles and peer-reviewed conference papers. Both lists can be filtered by year, indexing database and research domain.';
$ph_crumbs = [['label' => 'Publications']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/publications-subnav.php';
?>

<section class="section">
  <div class="container">

    <div class="grid grid-4" style="margin-bottom:44px;">
      <div class="metric-card">
        <span class="metric-value"><?= e((string) count($all)) ?></span>
        <span class="metric-label">Total publications</span>
        <span class="metric-note"><?= e((string) count($years)) ?> years of output</span>
      </div>
      <div class="metric-card">
        <span class="metric-value"><?= e((string) count($journal)) ?></span>
        <span class="metric-label">Journal articles</span>
        <span class="metric-note">Peer-reviewed, indexed venues</span>
      </div>
      <div class="metric-card">
        <span class="metric-value"><?= e((string) count($conference)) ?></span>
        <span class="metric-label">Conference papers</span>
        <span class="metric-note">Proceedings, oral and poster</span>
      </div>
      <div class="metric-card">
        <span class="metric-value"><?= e((string) $oaCount) ?></span>
        <span class="metric-label">Open access</span>
        <span class="metric-note"><?= e((string) $q1Count) ?> in Q1-ranked journals</span>
      </div>
    </div>

    <div class="grid grid-2" style="margin-bottom:52px;">
      <a class="card card--pad-lg" href="<?= e(url('/publications/journal/')) ?>" style="text-decoration:none;">
        <div class="icon-badge"><?= icon('document') ?></div>
        <h3>Journal articles</h3>
        <p>Indexed peer-reviewed articles grouped by year, with Scopus, SCIE/ESCI, quartile and open-access badges, and a resolving DOI for every entry.</p>
        <div class="card-foot"><span class="arrow-link">Browse <?= e((string) count($journal)) ?> articles</span></div>
      </a>
      <a class="card card--pad-lg" href="<?= e(url('/publications/conference/')) ?>" style="text-decoration:none;">
        <div class="icon-badge"><?= icon('users') ?></div>
        <h3>Conference papers</h3>
        <p>Proceedings papers, oral presentations and posters with the venue, location, presentation date and the indexing database of the proceedings.</p>
        <div class="card-foot"><span class="arrow-link">Browse <?= e((string) count($conference)) ?> papers</span></div>
      </a>
    </div>

    <div class="section-head">
      <span class="kicker">Most recent</span>
      <h2>Latest output</h2>
    </div>

    <ul class="pub-list">
      <?php foreach ($recent as $p): ?>
        <?= publication_item($p, isset($p['location']) ? 'conference' : 'journal') ?>
      <?php endforeach; ?>
    </ul>

  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">Publication policy</span>
        <h2>How we decide where to publish</h2>
        <p>Target venues are checked against index listings and publisher records before submission. The group does not publish in unindexed pay-to-publish venues, and does not add authors who have not contributed substantively to the work.</p>
        <p>Where article processing charges apply and are not covered by a waiver, the decision goes to the steering committee — a trainee is never asked to pay for their own publication.</p>
      </div>
      <div>
        <div class="divider-label">Standing rules</div>
        <ul class="info-list">
          <li><span class="label">Authorship</span><span class="value">Agreed in writing before the first draft; based on contribution, not seniority.</span></li>
          <li><span class="label">Data</span><span class="value">A data availability statement with a public deposit, or a documented reason why not.</span></li>
          <li><span class="label">Code</span><span class="value">Tagged at the version used for the results and archived with a DOI at acceptance.</span></li>
          <li><span class="label">Review</span><span class="value">Two internal reviews before any manuscript leaves the group.</span></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
