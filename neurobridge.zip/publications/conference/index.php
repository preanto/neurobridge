<?php
/** Conference papers, filterable by year, indexing database and domain. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Conference Papers';
$page_description = 'Indexed conference papers, proceedings, oral presentations and posters from Neurobridge Research, with venue, location and date.';

$rows = $PUBLICATIONS['conference'];

$fYear   = query('year');
$fIndex  = query('index');
$fDomain = query('domain');
$fType   = query('type');
$fSearch = query('q');

$years   = column_options($rows, 'year', true);
$indexes = column_options($rows, 'indexes');
$domains = column_options($rows, 'domains');
$types   = column_options($rows, 'type');

$filtered = filter_publications($rows, $fYear, $fIndex, $fDomain, $fSearch);
if ($fType !== '') {
    $filtered = array_values(array_filter($filtered, fn ($p) => ($p['type'] ?? '') === $fType));
}
usort($filtered, static fn ($a, $b) => $b['year'] <=> $a['year']);

$byYear = [];
foreach ($filtered as $row) {
    $byYear[(string) $row['year']][] = $row;
}

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Conference papers';
$ph_lead   = 'Proceedings papers, oral presentations and posters. Each entry lists the venue, location, presentation date and where the proceedings are indexed.';
$ph_crumbs = [['label' => 'Publications', 'path' => '/publications/'], ['label' => 'Conference']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/publications-subnav.php';
?>

<section class="section">
  <div class="container">

    <form class="filter-bar" method="get" data-autosubmit>
      <div class="filter-grid">
        <div>
          <label class="field-label" for="year">Year</label>
          <select class="select" name="year" id="year">
            <option value="">All years</option>
            <?php foreach ($years as $y): ?>
              <option value="<?= e($y) ?>"<?= $fYear === $y ? ' selected' : '' ?>><?= e($y) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="index">Indexed in</label>
          <select class="select" name="index" id="index">
            <option value="">All databases</option>
            <?php foreach ($indexes as $i): ?>
              <option value="<?= e($i) ?>"<?= $fIndex === $i ? ' selected' : '' ?>><?= e($i) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="type">Presentation</label>
          <select class="select" name="type" id="type">
            <option value="">All types</option>
            <?php foreach ($types as $t): ?>
              <option value="<?= e($t) ?>"<?= $fType === $t ? ' selected' : '' ?>><?= e($t) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="domain">Research domain</label>
          <select class="select" name="domain" id="domain">
            <option value="">All domains</option>
            <?php foreach ($domains as $d): ?>
              <option value="<?= e($d) ?>"<?= $fDomain === $d ? ' selected' : '' ?>><?= e($d) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="q">Search</label>
          <input class="input" type="search" name="q" id="q" value="<?= e($fSearch) ?>" placeholder="Title, author or conference">
        </div>
        <div class="filter-actions">
          <button class="btn btn-primary btn-sm" type="submit">Apply</button>
          <a class="btn btn-outline btn-sm" href="<?= e(url('/publications/conference/')) ?>">Reset</a>
        </div>
      </div>
    </form>

    <p class="result-count">Showing <?= e((string) count($filtered)) ?> of <?= e((string) count($rows)) ?> conference papers</p>

    <?php if (!$filtered): ?>
      <div class="empty-state">
        <p>No papers match these filters.</p>
        <a class="btn btn-outline btn-sm" href="<?= e(url('/publications/conference/')) ?>">Clear filters</a>
      </div>
    <?php else: ?>
      <?php foreach ($byYear as $year => $items): ?>
        <div class="divider-label" style="margin-top:38px;"><?= e((string) $year) ?> · <?= e((string) count($items)) ?> paper<?= count($items) === 1 ? '' : 's' ?></div>
        <ul class="pub-list">
          <?php foreach ($items as $p): ?>
            <?= publication_item($p, 'conference') ?>
          <?php endforeach; ?>
        </ul>
      <?php endforeach; ?>
    <?php endif; ?>

    <div class="note-box" style="margin-top:44px;">
      <strong>Presenting on our behalf</strong>
      Conference registration and travel support is available to members presenting accepted work. Requests go to the steering committee at least eight weeks before the event.
    </div>

  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
