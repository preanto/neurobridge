<?php
/** Journal articles, filterable by year, index database and domain. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Journal Articles';
$page_description = 'Peer-reviewed journal articles from Neurobridge Research, filterable by year, indexing database and research domain, each with a resolving DOI.';

$rows = $PUBLICATIONS['journal'];

$fYear   = query('year');
$fIndex  = query('index');
$fDomain = query('domain');
$fSearch = query('q');

$years   = column_options($rows, 'year', true);
$indexes = column_options($rows, 'indexes');
$domains = column_options($rows, 'domains');

$filtered = filter_publications($rows, $fYear, $fIndex, $fDomain, $fSearch);
usort($filtered, static fn ($a, $b) => $b['year'] <=> $a['year']);

// Group the results by year for the listing.
$byYear = [];
foreach ($filtered as $row) {
    $byYear[(string) $row['year']][] = $row;
}

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Journal articles';
$ph_lead   = 'Peer-reviewed articles published in indexed journals. Badges show the indexing database and journal quartile; every entry links to its DOI.';
$ph_crumbs = [['label' => 'Publications', 'path' => '/publications/'], ['label' => 'Journal']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/publications-subnav.php';
?>

<section class="section">
  <div class="container">

    <form class="filter-bar" method="get" data-autosubmit>
      <div class="filter-grid">
        <div>
          <label class="field-label" for="year">Year</label>
          <select class="select" name="year" id="year">
            <option value="">All years</option>
            <?php foreach ($years as $y): ?>
              <option value="<?= e($y) ?>"<?= $fYear === $y ? ' selected' : '' ?>><?= e($y) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="index">Indexed in</label>
          <select class="select" name="index" id="index">
            <option value="">All databases</option>
            <?php foreach ($indexes as $i): ?>
              <option value="<?= e($i) ?>"<?= $fIndex === $i ? ' selected' : '' ?>><?= e($i) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="domain">Research domain</label>
          <select class="select" name="domain" id="domain">
            <option value="">All domains</option>
            <?php foreach ($domains as $d): ?>
              <option value="<?= e($d) ?>"<?= $fDomain === $d ? ' selected' : '' ?>><?= e($d) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="q">Search</label>
          <input class="input" type="search" name="q" id="q" value="<?= e($fSearch) ?>" placeholder="Title, author or journal">
        </div>
        <div class="filter-actions">
          <button class="btn btn-primary btn-sm" type="submit">Apply</button>
          <a class="btn btn-outline btn-sm" href="<?= e(url('/publications/journal/')) ?>">Reset</a>
        </div>
      </div>
    </form>

    <p class="result-count">Showing <?= e((string) count($filtered)) ?> of <?= e((string) count($rows)) ?> journal articles</p>

    <?php if (!$filtered): ?>
      <div class="empty-state">
        <p>No articles match these filters.</p>
        <a class="btn btn-outline btn-sm" href="<?= e(url('/publications/journal/')) ?>">Clear filters</a>
      </div>
    <?php else: ?>
      <?php foreach ($byYear as $year => $items): ?>
        <div class="divider-label" style="margin-top:38px;"><?= e((string) $year) ?> · <?= e((string) count($items)) ?> article<?= count($items) === 1 ? '' : 's' ?></div>
        <ul class="pub-list">
          <?php foreach ($items as $p): ?>
            <?= publication_item($p, 'journal') ?>
          <?php endforeach; ?>
        </ul>
      <?php endforeach; ?>
    <?php endif; ?>

    <div class="note-box" style="margin-top:44px;">
      <strong>Citation and reuse</strong>
      Author-accepted manuscripts are available on request for any article that is not open access. Write to
      <a href="mailto:<?= e($SITE['contact']['email']) ?>"><?= e($SITE['contact']['email']) ?></a> with the DOI.
    </div>

  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
