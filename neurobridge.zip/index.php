<?php
/** Home page. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$page_title       = '';
$page_description = $SITE['meta_description'];

$latestNews   = array_slice($NEWS, 0, 6);
$recentEvents = array_slice($EVENTS['past'], 0, 3);
$featuredScholars = array_slice($TEAM['scholars'], 0, 4);

require APP_ROOT . '/includes/header.php';
?>

<!-- Hero ------------------------------------------------------------------>
<section class="hero">
  <div class="container">
    <div class="hero-grid">
      <div>
        <span class="kicker kicker--light">Bioscience research &amp; training · Dhaka, Bangladesh</span>
        <h1>Bridging Minds, Advancing Neuroscience</h1>
        <p><?= e($SITE['intro']) ?> We pair computational discovery with laboratory validation, and every project is built so that a trainee can enter as a student and leave as a published investigator.</p>
        <div class="btn-row">
          <a class="btn btn-light" href="<?= e(url('/research/')) ?>">Explore our research</a>
          <a class="btn btn-ghost-light" href="<?= e(url('/join/')) ?>">Join the lab</a>
          <a class="btn btn-ghost-light" href="<?= e(url('/publications/journal/')) ?>">Publications</a>
        </div>
      </div>

      <div class="hero-panel">
        <h2>Core disciplines</h2>
        <div class="hero-disciplines">
          <?php foreach ($RESEARCH['domains'] as $domain): ?>
            <a href="<?= e(url('/research/#' . $domain['slug'])) ?>"><?= e($domain['title']) ?></a>
          <?php endforeach; ?>
        </div>
        <div class="hero-stats">
          <?php foreach (array_slice($SITE['metrics'], 0, 3) as $m): ?>
            <div>
              <strong><?= e(metric((int) $m['value'], (string) $m['suffix'])) ?></strong>
              <span><?= e($m['label']) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- News ticker ----------------------------------------------------------->
<!-- <div class="ticker">
  <div class="container">
    <span class="ticker-label"><span class="ticker-dot"></span> Latest</span>
    <div class="ticker-viewport">
      <div class="ticker-track">
        <?php foreach ($latestNews as $item): ?>
          <a href="<?= e(url($item['url'])) ?>">
            <span class="ticker-tag"><?= e($item['tag']) ?></span>
            <?= e($item['title']) ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div> -->

<!-- About ----------------------------------------------------------------->
<section class="section">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">About us</span>
        <h2>An interdisciplinary research organisation built around mentorship</h2>
        <?php foreach ($SITE['about'] as $paragraph): ?>
          <p class="lead"><?= e($paragraph) ?></p>
        <?php endforeach; ?>
        <div class="btn-row mt-3">
          <a class="btn btn-outline" href="<?= e(url('/research/')) ?>">Research overview</a>
          <a class="btn btn-outline" href="<?= e(url('/team/')) ?>">Meet the team</a>
        </div>
      </div>

      <div class="grid" style="gap:20px;">
        <div class="card card--flat">
          <div class="icon-badge"><?= icon('target') ?></div>
          <h3>Our mission</h3>
          <p><?= e($SITE['mission']) ?></p>
        </div>
        <div class="card card--flat">
          <div class="icon-badge"><?= icon('globe') ?></div>
          <h3>Our vision</h3>
          <p><?= e($SITE['vision']) ?></p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- What we do ------------------------------------------------------------>
<section class="section section--surface">
  <div class="container">
    <div class="section-head">
      <span class="kicker">What we do</span>
      <h2>Six activities that keep research and training in the same loop</h2>
      <p>Discovery, teaching and dissemination are run as one programme — the people who produce the science also write the training material and release the data.</p>
    </div>

    <div class="grid grid-3">
      <?php foreach ($SITE['what_we_do'] as $item): ?>
        <div class="card">
          <div class="icon-badge"><?= icon($item['icon']) ?></div>
          <h3><?= e($item['title']) ?></h3>
          <p><?= e($item['text']) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Research domains ------------------------------------------------------>
<section class="section">
  <div class="container">
    <div class="section-head section-head--split">
      <div>
        <span class="kicker">Research domains</span>
        <h2>Seven disciplines, staffed across every project</h2>
        <p>No project is assigned to a single discipline. A computational finding is validated at the bench; a bench observation is interrogated computationally.</p>
      </div>
      <a class="arrow-link" href="<?= e(url('/research/')) ?>">Full research overview</a>
    </div>

    <div class="grid grid-auto">
      <?php foreach ($RESEARCH['domains'] as $domain): ?>
        <a class="card domain-card" href="<?= e(url('/research/#' . $domain['slug'])) ?>" style="text-decoration:none;">
          <div class="icon-badge"><?= icon($domain['icon']) ?></div>
          <h3><?= e($domain['title']) ?></h3>
          <p><?= e($domain['summary']) ?></p>
          <div class="domain-meta"><?= e((string) $domain['projects']) ?> active &amp; completed projects</div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Impact metrics -------------------------------------------------------->
<section class="section section--tint">
  <div class="container">
    <div class="section-head section-head--center">
      <span class="kicker">Impact</span>
      <h2>Where we are today</h2>
      <p>Figures reviewed at the end of each academic year by the steering committee.</p>
    </div>

    <div class="grid grid-3">
      <?php foreach ($SITE['metrics'] as $m): ?>
        <div class="metric-card">
          <span class="metric-value"><?= e(metric((int) $m['value'], (string) $m['suffix'])) ?></span>
          <span class="metric-label"><?= e($m['label']) ?></span>
          <span class="metric-note"><?= e($m['note']) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Wall of Scholars highlight -------------------------------------------->
<section class="section">
  <div class="container">
    <div class="section-head section-head--split">
      <div>
        <span class="kicker">Wall of Scholars</span>
        <h2>Members placed in funded graduate programmes worldwide</h2>
        <p>Thirty-one members have moved from a Neurobridge project into a funded MS or PhD position. Higher-study guidance is part of the fellowship, not an extra.</p>
      </div>
      <a class="arrow-link" href="<?= e(url('/team/scholars/')) ?>">See the full wall</a>
    </div>

    <div class="grid grid-4">
      <?php foreach ($featuredScholars as $s): ?>
        <div class="scholar-card">
          <?= person_photo($s) ?>
          <div class="person-card-body">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
              <p class="person-name"><?= e($s['name']) ?></p>
              <span class="flag-chip"><?= e($s['flag']) ?></span>
            </div>
            <p class="scholar-university"><?= e($s['degree']) ?> · <?= e($s['university']) ?></p>
            <p class="scholar-meta"><?= e($s['field']) ?> · <?= e($s['country']) ?></p>
            <div class="scholar-funding"><?= icon('award', 'ico') ?> <span><?= e($s['funding']) ?></span></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Events & MoUs --------------------------------------------------------->
<!-- <section class="section section--surface">
  <div class="container">
    <div class="section-head section-head--split">
      <div>
        <span class="kicker">Events &amp; MoUs</span>
        <h2>Recent workshops, partnerships and conferences</h2>
        <p>Training events, memoranda of understanding and the conferences we organise or co-host.</p>
      </div>
      <a class="arrow-link" href="<?= e(url('/events/')) ?>">All events</a>
    </div>

    <div class="grid grid-3">
      <?php foreach ($recentEvents as $ev): ?>
        <article class="event-card">
          <div class="event-cover"><span class="badge"><?= e($ev['type']) ?></span></div>
          <div class="event-body">
            <div class="event-date"><?= e($ev['date_text']) ?></div>
            <h3><?= e($ev['title']) ?></h3>
            <div class="event-venue"><?= icon('pin', 'ico') ?><span><?= e($ev['venue']) ?></span></div>
            <p><?= e($ev['summary']) ?></p>
            <div class="card-foot"><a class="arrow-link" href="<?= e(url('/events/')) ?>">Event details</a></div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section> -->

<!-- Testimonials ---------------------------------------------------------->
<!-- <section class="section">
  <div class="container">
    <div class="section-head">
      <span class="kicker">Testimonials &amp; advisory notes</span>
      <h2>What members, advisers and partners say</h2>
    </div>

    <div class="grid grid-2">
      <?php foreach ($SITE['testimonials'] as $t): ?>
        <figure class="quote-card" style="margin:0;">
          <div class="quote-mark" aria-hidden="true">&ldquo;</div>
          <blockquote><?= e($t['quote']) ?></blockquote>
          <figcaption class="quote-author">
            <?= avatar($t['name'], 'avatar--sm') ?>
            <span>
              <span class="person-name"><?= e($t['name']) ?></span>
              <span class="person-affil"><?= e($t['role']) ?></span>
            </span>
          </figcaption>
        </figure>
      <?php endforeach; ?>
    </div>
  </div>
</section> -->

<!-- CTA ------------------------------------------------------------------->
<section class="cta-band">
  <div class="container">
    <div>
      <h2>Applications are open for the 2026–27 cohort</h2>
      <p>Twelve research fellowship places across all seven disciplines. No application fee, no tuition — selection is on written work and a short methods interview.</p>
    </div>
    <div class="btn-row">
      <a class="btn btn-light" href="<?= e(url('/join/')) ?>">Apply to join</a>
      <a class="btn btn-ghost-light" href="<?= e(url('/contact/')) ?>">Talk to us</a>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
