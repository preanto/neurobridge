<?php
/** Research fellows. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Research Fellows';
$page_description = 'Members of the Neurobridge Research fellowship track — the researchers leading individual workstreams and mentoring associates.';

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Research Fellows';
$ph_lead   = 'Fellows lead a workstream, keep its analysis log, write the first draft of its manuscript, and mentor the associates working with them. The track runs for twelve months and is renewable once.';
$ph_crumbs = [['label' => 'Team', 'path' => '/team/'], ['label' => 'Research Fellows']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/team-subnav.php';
?>

<section class="section">
  <div class="container">
    <div class="grid grid-3">
      <?php foreach ($TEAM['fellows'] as $person): ?>
        <article class="person-card">
          <?= person_photo($person, 'avatar--lg') ?>
          <div class="person-card-body">
            <h3 class="person-name"><?= e($person['name']) ?></h3>
            <p class="person-role"><?= e($person['role']) ?></p>
            <p class="person-affil"><?= e($person['term']) ?></p>
            <p class="person-bio mt-3"><?= e($person['bio']) ?></p>
            <div class="tag-row">
              <?php foreach ($person['domains'] as $d): ?>
                <span class="badge badge--brand"><?= e($d) ?></span>
              <?php endforeach; ?>
              <?php foreach ($person['interests'] as $i): ?>
                <span class="badge"><?= e($i) ?></span>
              <?php endforeach; ?>
            </div>
            <?= person_links($person['links']) ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">The fellowship</span>
        <h2>What a fellowship year involves</h2>
        <p>The fellowship is unpaid but fully resourced: computational access, publication fees where required, conference support, and structured supervision. It exists to take someone who has completed a first project and make them capable of running one.</p>
        <ul>
          <li>Twenty hours a week for twelve months, renewable once</li>
          <li>Ownership of one workstream inside a focus area</li>
          <li>First-author responsibility on at least one manuscript</li>
          <li>Mentorship of two to four research associates</li>
          <li>Higher-study application support in the final quarter</li>
        </ul>
        <div class="btn-row mt-3">
          <a class="btn btn-primary" href="<?= e(url('/join/')) ?>">Apply for a fellowship</a>
        </div>
      </div>

      <div class="grid" style="gap:16px;">
        <div class="card card--flat">
          <div class="icon-badge"><?= icon('document') ?></div>
          <h3>Expected output</h3>
          <p>One first-author manuscript submitted to an indexed journal, one conference presentation, and a released dataset or repository.</p>
        </div>
        <div class="card card--flat">
          <div class="icon-badge"><?= icon('users') ?></div>
          <h3>Supervision</h3>
          <p>Weekly one-to-one with the faculty lead, fortnightly workstream review, and a written progress report each quarter.</p>
        </div>
        <div class="card card--flat">
          <div class="icon-badge"><?= icon('globe') ?></div>
          <h3>After the fellowship</h3>
          <p>Most fellows apply for funded graduate study. Statement review, supervisor outreach strategy and funding search are part of the programme.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
