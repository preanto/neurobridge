<?php
/** Wall of Scholars — funded admits and scholarships. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Wall of Scholars';
$page_description = 'Neurobridge Research members placed in funded MS and PhD programmes worldwide, with university, country and funding details.';

$scholars = $TEAM['scholars'];

$fYear    = query('year');
$fCountry = query('country');
$fDegree  = query('degree');

$years     = column_options($scholars, 'year', true);
$countries = column_options($scholars, 'country');
$degrees   = column_options($scholars, 'degree');

$filtered = array_values(array_filter($scholars, static function (array $s) use ($fYear, $fCountry, $fDegree): bool {
    if ($fYear !== '' && (string) $s['year'] !== $fYear)       { return false; }
    if ($fCountry !== '' && $s['country'] !== $fCountry)       { return false; }
    if ($fDegree !== '' && $s['degree'] !== $fDegree)          { return false; }
    return true;
}));

usort($filtered, static fn ($a, $b) => $b['year'] <=> $a['year']);

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Wall of Scholars';
$ph_lead   = 'Members who moved from a Neurobridge project into a funded graduate programme. Placements are listed with the awarding institution and the funding instrument, published with each member\'s consent.';
$ph_crumbs = [['label' => 'Team', 'path' => '/team/'], ['label' => 'Wall of Scholars']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/team-subnav.php';
?>

<section class="section">
  <div class="container">

    <div class="grid grid-4" style="margin-bottom:36px;">
      <div class="metric-card">
        <span class="metric-value"><?= e((string) count($scholars)) ?></span>
        <span class="metric-label">Funded placements</span>
        <span class="metric-note">Listed on this page</span>
      </div>
      <div class="metric-card">
        <span class="metric-value"><?= e((string) count($countries)) ?></span>
        <span class="metric-label">Countries</span>
        <span class="metric-note">Across four continents</span>
      </div>
      <div class="metric-card">
        <span class="metric-value"><?= e((string) count(array_filter($scholars, fn ($s) => $s['degree'] === 'PhD'))) ?></span>
        <span class="metric-label">PhD positions</span>
        <span class="metric-note">Fully funded doctoral admits</span>
      </div>
      <div class="metric-card">
        <span class="metric-value"><?= e((string) count(array_filter($scholars, fn ($s) => $s['degree'] === 'MS'))) ?></span>
        <span class="metric-label">Master's positions</span>
        <span class="metric-note">With scholarship or assistantship</span>
      </div>
    </div>

    <form class="filter-bar" method="get" data-autosubmit>
      <div class="filter-grid">
        <div>
          <label class="field-label" for="year">Admission year</label>
          <select class="select" name="year" id="year">
            <option value="">All years</option>
            <?php foreach ($years as $y): ?>
              <option value="<?= e($y) ?>"<?= $fYear === $y ? ' selected' : '' ?>><?= e($y) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="country">Country</label>
          <select class="select" name="country" id="country">
            <option value="">All countries</option>
            <?php foreach ($countries as $c): ?>
              <option value="<?= e($c) ?>"<?= $fCountry === $c ? ' selected' : '' ?>><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="degree">Degree</label>
          <select class="select" name="degree" id="degree">
            <option value="">All degrees</option>
            <?php foreach ($degrees as $d): ?>
              <option value="<?= e($d) ?>"<?= $fDegree === $d ? ' selected' : '' ?>><?= e($d) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="filter-actions">
          <button class="btn btn-primary btn-sm" type="submit">Apply</button>
          <a class="btn btn-outline btn-sm" href="<?= e(url('/team/scholars/')) ?>">Reset</a>
        </div>
      </div>
    </form>

    <p class="result-count">Showing <?= e((string) count($filtered)) ?> of <?= e((string) count($scholars)) ?> placements</p>

    <?php if (!$filtered): ?>
      <div class="empty-state">
        <p>No placements match these filters.</p>
        <a class="btn btn-outline btn-sm" href="<?= e(url('/team/scholars/')) ?>">Clear filters</a>
      </div>
    <?php else: ?>
      <div class="grid grid-4">
        <?php foreach ($filtered as $s): ?>
          <article class="scholar-card">
            <?= person_photo($s) ?>
            <div class="person-card-body">
              <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                <p class="person-name"><?= e($s['name']) ?></p>
                <span class="badge badge--brand"><?= e((string) $s['year']) ?></span>
              </div>
              <p class="scholar-university"><?= e($s['degree']) ?> · <?= e($s['university']) ?></p>
              <p class="scholar-meta"><?= e($s['field']) ?></p>
              <p class="scholar-meta" style="margin-top:.35rem;"><span class="flag-chip"><?= e($s['flag']) ?></span> <?= e($s['country']) ?></p>
              <div class="scholar-funding"><?= icon('award', 'ico') ?> <span><?= e($s['funding']) ?></span></div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">How we support applications</span>
        <h2>Higher-study guidance is part of the programme</h2>
        <p>Research output alone does not secure funded admission. From the third quarter of a fellowship we work on the pieces that actually decide outcomes: a specific research statement, a shortlist of supervisors whose work genuinely overlaps, and correspondence that reads like a colleague rather than a form letter.</p>
        <ul>
          <li>Supervisor shortlisting and outreach strategy</li>
          <li>Statement of purpose and research proposal review</li>
          <li>Funding search — assistantships, national scholarships and mobility schemes</li>
          <li>Mock interviews with alumni in the destination country</li>
          <li>Reference letters grounded in documented contribution</li>
        </ul>
      </div>
      <div class="card card--pad-lg">
        <h3>A note on this page</h3>
        <p>We publish placements only with the member's written consent, and we list the funding instrument rather than amounts. Admission outcomes depend on many factors beyond our programme — this page records where our members went, not a guarantee of what any applicant will receive.</p>
        <div class="card-foot">
          <a class="btn btn-primary" href="<?= e(url('/join/')) ?>">Start with a research position</a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
