<?php
/** International collaborators and clinical mentors. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Collaborators';
$page_description = 'International faculty and clinical mentors collaborating with Neurobridge Research under standing agreements and memoranda of understanding.';

$countries = column_options($TEAM['collaborators'], 'country');

require APP_ROOT . '/includes/header.php';

$ph_title  = 'International collaborators';
$ph_lead   = 'Faculty and clinicians in ' . count($countries) . ' countries who co-supervise our fellows, share instrumentation, and co-author with our teams.';
$ph_crumbs = [['label' => 'Team', 'path' => '/team/'], ['label' => 'Collaborators']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/team-subnav.php';
?>

<section class="section">
  <div class="container">
    <div class="grid grid-2">
      <?php foreach ($TEAM['collaborators'] as $person): ?>
        <article class="person-card">
          <?= person_photo($person, 'avatar--lg') ?>
          <div class="person-card-body">
            <h3 class="person-name"><?= e($person['name']) ?></h3>
            <p class="person-role"><?= e($person['role']) ?></p>
            <p class="person-affil"><?= e($person['affiliation']) ?> · <span class="flag-chip"><?= e($person['flag']) ?></span> <?= e($person['country']) ?></p>
            <p class="person-bio mt-3"><strong>Collaboration:</strong> <?= e($person['focus']) ?></p>
            <div class="tag-row">
              <?php foreach ($person['domains'] as $d): ?>
                <span class="badge badge--brand"><?= e($d) ?></span>
              <?php endforeach; ?>
            </div>
            <?= person_links($person['links']) ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">Partnership model</span>
        <h2>What a collaboration with us looks like</h2>
        <p>We are a small organisation and we are explicit about it. Our contribution is disciplined execution: literature and data curation, computational analysis, structured experimental work, and a documented, reproducible record of everything we do.</p>
        <p>In return we ask for methodological supervision, access to instrumentation or cohorts our partners already hold, and fair authorship on the work our members produce.</p>
      </div>

      <div>
        <div class="divider-label">Countries represented</div>
        <ul class="pill-list">
          <?php foreach ($countries as $country): ?>
            <li><span><?= e($country) ?></span></li>
          <?php endforeach; ?>
        </ul>

        <div class="divider-label" style="margin-top:32px;">Forms of collaboration</div>
        <ul>
          <li>Co-supervision of research fellows</li>
          <li>Shared instrumentation and sample analysis</li>
          <li>Joint grant applications</li>
          <li>Student exchange under a memorandum of understanding</li>
          <li>External validation cohorts for predictive models</li>
        </ul>
        <a class="btn btn-primary mt-3" href="<?= e(url('/contact/')) ?>">Propose a collaboration</a>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
