<?php
/** Team overview. */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$page_title       = 'Team';
$page_description = 'Leadership, faculty, research fellows, associates, collaborators, committee members and alumni of Neurobridge Research.';

$counts = [
    'researchers'   => count($TEAM['leadership']) + count($TEAM['faculty']) + count($TEAM['researchers']),
    'fellows'       => count($TEAM['fellows']),
    'collaborators' => count($TEAM['collaborators']),
    'scholars'      => count($TEAM['scholars']),
    'committee'     => count($TEAM['committee']),
    'alumni'        => count($TEAM['alumni']),
];

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Our team';
$ph_lead   = 'Neurobridge is organised in tiers so that every trainee works next to someone one step ahead of them.';
$ph_crumbs = [['label' => 'Team']];
require APP_ROOT . '/includes/partials/page-header.php';
#require APP_ROOT . '/includes/partials/team-subnav.php';
?>

<section class="section">
  <div class="container">

    <div class="section-head">
      <span class="kicker">Leadership</span>
      <h2>Principal investigators &amp; directors</h2>
      <p>The three people accountable for the scientific programme, research integrity and the training pipeline.</p>
    </div>

    <div class="grid grid-3">
      <?php foreach ($TEAM['leadership'] as $person): ?>
          <article class="person-card">
            <?= person_photo($person, 'avatar--lg') ?>
            <div class="person-card-body">
              <h3 class="person-name"><?= e($person['name']) ?></h3>
              <p class="person-role"><?= e($person['role']) ?></p>
              <p class="person-affil"><?= e($person['affiliation']) ?></p>
              <p class="person-bio mt-3"><?= e($person['bio']) ?></p>
              <div class="tag-row">
                <?php foreach ($person['domains'] as $d): ?>
                    <span class="badge badge--brand"><?= e($d) ?></span>
                <?php endforeach; ?>
              </div>
              <?= person_links($person['links']) ?>
            </div>
          </article>
      <?php endforeach; ?>
    </div>
  </div>
<div class="container">
  <div class="section-head" style="margin-top:64px;">
      <span class="kicker">Core faculty</span>
      <h2>Discipline leads &amp; mentors</h2>
      <p>Each of the seven disciplines has a faculty lead who supervises methodology, safety and trainee progression within that domain.</p>
    </div>

    <div class="grid grid-3">
      <?php foreach ($TEAM['faculty'] as $person): ?>
        <article class="person-card">
          <?= person_photo($person) ?>
          <div class="person-card-body">
            <h3 class="person-name"><?= e($person['name']) ?></h3>
            <p class="person-role"><?= e($person['role']) ?></p>
            <p class="person-affil"><?= e($person['affiliation']) ?></p>
            <p class="person-bio mt-3"><?= e($person['bio']) ?></p>
            <div class="tag-row">
              <?php foreach ($person['interests'] as $i): ?>
                <span class="badge"><?= e($i) ?></span>
              <?php endforeach; ?>
            </div>
            <?= person_links($person['links']) ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    </div>
</section>


<section class="section section--surface">
  
  <div class="container">
    <div class="section-head">
      <span class="kicker">Sections</span>
      <h2>Meet our Research Team</h2>
      <p>Each group has its own page with roles, affiliations, research interests and contact links.</p>
    </div>
    <div class="grid grid-3">
      <?php foreach ($TEAM['fellows'] as $person): ?>
        <article class="person-card">
          <?= person_photo($person, 'avatar--lg') ?>
          <div class="person-card-body">
            <h3 class="person-name"><?= e($person['name']) ?></h3>
            <p class="person-role"><?= e($person['role']) ?></p>
            <p class="person-affil"><?= e($person['affiliation']) ?></p>
 
            <?= person_links($person['links']) ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

</section>

<section class="section">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">How we work</span>
        <h2>Tiered teams, written expectations</h2>
        <p>A project team is normally one faculty mentor, one research fellow and two to four associates. Responsibilities, authorship criteria and the expected output are agreed in writing at the start — before the first experiment.</p>
        <p>Associates commit ten hours a week for a minimum of six months. Fellows commit twenty and take responsibility for a workstream, the analysis log and the first draft of the manuscript.</p>
        <div class="btn-row mt-3">
          <a class="btn btn-primary" href="<?= e(url('/join/')) ?>">Join the team</a>
          <a class="btn btn-outline" href="<?= e(url('/resources/templates/')) ?>">See our working templates</a>
        </div>
      </div>

      <div class="grid" style="gap:16px;">
        <?php foreach ($SITE['values'] as $v): ?>
          <div class="card card--flat">
            <h3 style="font-size:1rem;"><?= e($v['title']) ?></h3>
            <p><?= e($v['text']) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
