<?php
/** Advisory, steering and ethics committee members. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Committee';
$page_description = 'Scientific advisory, steering, and governance & ethics committee members of Neurobridge Research and their remits.';

$bodies = [
    'Advisory' => [
        'title' => 'Scientific Advisory Committee',
        'text'  => 'Reviews the scientific programme annually, approves new focus areas, and provides methodological and biosafety oversight.',
    ],
    'Steering' => [
        'title' => 'Steering Committee',
        'text'  => 'Responsible for operations, budget, programme prioritisation, research integrity and member welfare.',
    ],
    'Ethics' => [
        'title' => 'Governance &amp; Ethics',
        'text'  => 'Oversees consent frameworks, data protection, human-participant review and institutional agreements.',
    ],
];

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Committees';
$ph_lead   = 'Three standing bodies govern the organisation: one for scientific direction, one for operations, and one for ethics and governance.';
$ph_crumbs = [['label' => 'Team', 'path' => '/team/'], ['label' => 'Committee']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/team-subnav.php';
?>

<section class="section">
  <div class="container">
    <?php $first = true; ?>
    <?php foreach ($bodies as $key => $body): ?>
      <?php $members = array_values(array_filter($TEAM['committee'], fn ($m) => $m['body'] === $key)); ?>
      <?php if (!$members) { continue; } ?>

      <div class="section-head" style="<?= $first ? '' : 'margin-top:64px;' ?>">
        <span class="kicker"><?= e((string) count($members)) ?> members</span>
        <h2><?= $body['title'] ?></h2>
        <p><?= $body['text'] ?></p>
      </div>

      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th scope="col">Member</th>
              <th scope="col">Role</th>
              <th scope="col">Affiliation</th>
              <th scope="col">Remit</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($members as $m): ?>
              <tr>
                <td>
                  <span style="display:inline-flex;align-items:center;gap:10px;">
                    <?= person_photo($m, 'avatar--sm') ?>
                    <strong><?= e($m['name']) ?></strong>
                  </span>
                </td>
                <td><?= e($m['role']) ?></td>
                <td><?= e($m['affiliation']) ?></td>
                <td><?= e($m['remit']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php $first = false; ?>
    <?php endforeach; ?>
  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="grid grid-3">
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('calendar') ?></div>
        <h3>Meeting cadence</h3>
        <p>The steering committee meets monthly, the advisory committee twice a year, and the ethics group convenes for every study involving human participants or identifiable data.</p>
      </div>
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('document') ?></div>
        <h3>Conflict of interest</h3>
        <p>Members declare interests annually and recuse themselves from decisions involving their own department, funding source or supervised trainees.</p>
      </div>
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('check') ?></div>
        <h3>Raising a concern</h3>
        <p>Any member, collaborator or participant may write to the ethics group directly. Concerns about research integrity are recorded and answered in writing.</p>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
