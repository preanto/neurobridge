<?php
/** Researchers: PI, core faculty, associates and undergraduate assistants. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Researchers';
$page_description = 'Principal investigators, core faculty, research associates and undergraduate research assistants at Neurobridge Research.';

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Researchers';
$ph_lead   = 'The people who design and run our studies — from principal investigators to the undergraduate assistants taking their first steps in research.';
$ph_crumbs = [['label' => 'Team', 'path' => '/team/'], ['label' => 'Researchers']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/team-subnav.php';
?>

<section class="section">
  <div class="container">

    <div class="section-head">
      <span class="kicker">Principal investigators</span>
      <h2>Leadership</h2>
    </div>

    <div class="grid grid-3">
      <?php foreach ($TEAM['leadership'] as $person): ?>
        <article class="person-card">
          <?= person_photo($person, 'avatar--lg') ?>
          <div class="person-card-body">
            <h3 class="person-name"><?= e($person['name']) ?></h3>
            <p class="person-role"><?= e($person['role']) ?></p>
            <p class="person-affil"><?= e($person['affiliation']) ?></p>
            <p class="person-bio mt-3"><?= e($person['bio']) ?></p>
            <div class="tag-row">
              <?php foreach ($person['interests'] as $i): ?>
                <span class="badge"><?= e($i) ?></span>
              <?php endforeach; ?>
            </div>
            <?= person_links($person['links']) ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

    <div class="section-head mt-4" style="margin-top:64px;">
      <span class="kicker">Core faculty</span>
      <h2>Discipline leads &amp; mentors</h2>
      <p>Each of the seven disciplines has a faculty lead who supervises methodology, safety and trainee progression within that domain.</p>
    </div>

    <div class="grid grid-3">
      <?php foreach ($TEAM['faculty'] as $person): ?>
        <article class="person-card">
          <?= person_photo($person) ?>
          <div class="person-card-body">
            <h3 class="person-name"><?= e($person['name']) ?></h3>
            <p class="person-role"><?= e($person['role']) ?></p>
            <p class="person-affil"><?= e($person['affiliation']) ?></p>
            <p class="person-bio mt-3"><?= e($person['bio']) ?></p>
            <div class="tag-row">
              <?php foreach ($person['interests'] as $i): ?>
                <span class="badge"><?= e($i) ?></span>
              <?php endforeach; ?>
            </div>
            <?= person_links($person['links']) ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="section-head section-head--split">
      <div>
        <span class="kicker">Active members</span>
        <h2>Research associates &amp; undergraduate assistants</h2>
        <p><?= e((string) count($TEAM['researchers'])) ?> members currently contributing to project teams across all seven disciplines.</p>
      </div>
      <div style="min-width:250px;">
        <label class="field-label" for="memberSearch">Search members</label>
        <input class="input" type="search" id="memberSearch" data-filter-input placeholder="Name, university or interest">
      </div>
    </div>

    <div class="grid grid-3">
      <?php foreach ($TEAM['researchers'] as $person): ?>
        <div class="person-card" data-filter-item>
          <?= person_photo($person) ?>
          <div class="person-card-body">
            <p class="person-name"><?= e($person['name']) ?></p>
            <p class="person-role" style="font-size:.76rem;"><?= e($person['role']) ?></p>
            <p class="person-affil"><?= e($person['affiliation']) ?> · <?= e(implode(', ', $person['domains'])) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <p class="result-count mt-3"><span data-filter-count><?= e((string) count($TEAM['researchers'])) ?> results</span></p>
  </div>
</section>

<section class="cta-band">
  <div class="container">
    <div>
      <h2>Want your name on this page?</h2>
      <p>Associate positions open twice a year. You need curiosity, ten hours a week and a willingness to write — the methods we will teach you.</p>
    </div>
    <div class="btn-row">
      <a class="btn btn-light" href="<?= e(url('/join/')) ?>">Application details</a>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
