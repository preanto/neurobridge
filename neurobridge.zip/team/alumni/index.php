<?php
/** Alumni — previous graduates and past lab members. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Alumni';
$page_description = 'Previous graduates and past members of Neurobridge Research, and where their work has taken them.';

$alumni = $TEAM['alumni'];

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Alumni';
$ph_lead   = 'Former fellows and associates. Many stay involved as mentors on the higher-study panel or as co-authors on continuing projects.';
$ph_crumbs = [['label' => 'Team', 'path' => '/team/'], ['label' => 'Alumni']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/team-subnav.php';
?>

<section class="section">
  <div class="container">

    <div class="section-head section-head--split">
      <div>
        <span class="kicker"><?= e((string) count($alumni)) ?> alumni</span>
        <h2>Where our members are now</h2>
      </div>
      <div style="min-width:260px;">
        <label class="field-label" for="alumniSearch">Search alumni</label>
        <input class="input" type="search" id="alumniSearch" data-filter-input placeholder="Name, institution or domain">
      </div>
    </div>

    <div class="table-wrap">
      <table class="data">
        <thead>
          <tr>
            <th scope="col">Member</th>
            <th scope="col">With us</th>
            <th scope="col">Role held</th>
            <th scope="col">Domain</th>
            <th scope="col">Currently</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($alumni as $a): ?>
            <tr data-filter-item>
              <td>
                <span style="display:inline-flex;align-items:center;gap:10px;">
                  <?= person_photo($a, 'avatar--sm') ?>
                  <strong><?= e($a['name']) ?></strong>
                </span>
              </td>
              <td><?= e($a['years']) ?></td>
              <td><?= e($a['role']) ?></td>
              <td>
                <?php foreach ($a['domains'] as $d): ?>
                  <span class="badge badge--brand"><?= e($d) ?></span>
                <?php endforeach; ?>
              </td>
              <td><?= e($a['now']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <p class="result-count mt-3"><span data-filter-count><?= e((string) count($alumni)) ?> results</span></p>
  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">Alumni network</span>
        <h2>Staying connected after you leave</h2>
        <p>Alumni keep access to the group's internal templates and analysis repositories, and are invited to the annual review meeting. In return, most contribute an hour or two a month to the higher-study panel — reading statements, sitting mock interviews and answering questions about the countries they now study in.</p>
        <p>If you were a member and are not listed here, or your details have changed, write to us and we will update the page.</p>
        <div class="btn-row mt-3">
          <a class="btn btn-primary" href="<?= e(url('/contact/')) ?>">Update your record</a>
          <a class="btn btn-outline" href="<?= e(url('/team/scholars/')) ?>">Wall of Scholars</a>
        </div>
      </div>

      <div class="card card--pad-lg">
        <h3>Alumni contributions in the past year</h3>
        <ul class="info-list">
          <li><span class="label">Panels</span><span class="value">6 higher-study sessions hosted with 400+ attendees</span></li>
          <li><span class="label">Reviews</span><span class="value">38 statements of purpose read and commented on</span></li>
          <li><span class="label">Co-authorship</span><span class="value">9 continuing manuscripts with former members</span></li>
          <li><span class="label">Teaching</span><span class="value">4 workshop sessions delivered remotely</span></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
