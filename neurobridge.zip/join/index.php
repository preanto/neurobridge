<?php
/** Recruitment: eligibility, application form and FAQs. */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$page_title       = 'Join Us';
$page_description = 'Eligibility criteria, application form and frequently asked questions for research positions and fellowships at Neurobridge Research.';

$positions = [
    'Undergraduate Research Assistant',
    'Research Associate',
    'Research Fellow',
    'Volunteer contributor (remote)',
];

$domainNames = array_column($RESEARCH['domains'], 'title');

$errors  = [];
$success = false;
$old     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = [
        'full_name'   => post('full_name'),
        'email'       => post('email'),
        'phone'       => post('phone'),
        'institution' => post('institution'),
        'department'  => post('department'),
        'level'       => post('level'),
        'year'        => post('year'),
        'position'    => post('position'),
        'hours'       => post('hours'),
        'skills'      => post('skills'),
        'motivation'  => post('motivation'),
        'portfolio'   => post('portfolio'),
        'referral'    => post('referral'),
    ];
    $selectedDomains = array_values(array_intersect((array) ($_POST['domains'] ?? []), $domainNames));

    if (!csrf_valid($_POST['_token'] ?? null)) {
        $errors[] = 'Your session expired. Please submit the form again.';
    }
    if (post('website') !== '') {                       // honeypot
        $errors[] = 'This submission was rejected as automated.';
    }
    if ($old['full_name'] === '')  { $errors['full_name']  = 'Please enter your full name.'; }
    if (!valid_email($old['email'])) { $errors['email']    = 'Please enter a valid e-mail address.'; }
    if ($old['institution'] === '') { $errors['institution'] = 'Please enter your institution.'; }
    if (!in_array($old['position'], $positions, true)) { $errors['position'] = 'Please choose the position you are applying for.'; }
    if (!$selectedDomains)          { $errors['domains']   = 'Select at least one research domain.'; }
    if (mb_strlen($old['motivation']) < 80) { $errors['motivation'] = 'Please write at least a short paragraph (80 characters or more).'; }
    if (empty($_POST['consent']))   { $errors['consent']   = 'Please confirm that we may store your application.'; }

    if (!$errors) {
        store_submission('application', $old + ['domains' => $selectedDomains]);
        $success = true;
        $old     = [];
        $selectedDomains = [];
    }
}

$val = static fn (string $key): string => e($old[$key] ?? '');

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Join the lab';
$ph_lead   = 'We recruit twice a year across all seven disciplines. Selection is on written work and a short methods conversation — not on your CGPA, your university, or who you know.';
$ph_crumbs = [['label' => 'Join Us']];
require APP_ROOT . '/includes/partials/page-header.php';
?>

<!-- Positions ------------------------------------------------------------->
<section class="section">
  <div class="container">
    <div class="section-head">
      <span class="kicker">Open positions</span>
      <h2>Four ways to work with us</h2>
      <p>All positions are unpaid but fully resourced: computational access, publication costs, conference support and structured supervision are covered by the organisation.</p>
    </div>

    <div class="grid grid-4">
      <div class="card">
        <div class="icon-badge"><?= icon('book') ?></div>
        <h3>Undergraduate Research Assistant</h3>
        <p>For students in their second year or later. Ten hours a week, six-month minimum, working inside an existing project team.</p>
        <div class="tag-row"><span class="badge badge--ok">Open</span><span class="badge">10 h/week</span></div>
      </div>
      <div class="card">
        <div class="icon-badge"><?= icon('flask') ?></div>
        <h3>Research Associate</h3>
        <p>For graduates or final-year students with a completed project. Ownership of a defined task with co-authorship on the resulting paper.</p>
        <div class="tag-row"><span class="badge badge--ok">Open</span><span class="badge">12–15 h/week</span></div>
      </div>
      <div class="card">
        <div class="icon-badge"><?= icon('award') ?></div>
        <h3>Research Fellow</h3>
        <p>Twelve months, renewable. Leads a workstream, first-author responsibility on a manuscript, and mentors two to four associates.</p>
        <div class="tag-row"><span class="badge badge--ok">12 places</span><span class="badge">20 h/week</span></div>
      </div>
      <div class="card">
        <div class="icon-badge"><?= icon('globe') ?></div>
        <h3>Volunteer contributor</h3>
        <p>Fully remote, flexible. Literature curation, data annotation, translation and training support for those who cannot commit fixed hours.</p>
        <div class="tag-row"><span class="badge badge--ok">Rolling</span><span class="badge">Flexible</span></div>
      </div>
    </div>
  </div>
</section>

<!-- Eligibility ----------------------------------------------------------->
<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">Eligibility</span>
        <h2>What we ask for</h2>
        <p>We are looking for people who will still be here in six months. Prior research experience is welcome but not required — the methods are teachable, the commitment is not.</p>
        <ul>
          <li>Enrolled in, or a graduate of, a bioscience, chemistry, pharmacy, medical or computing programme</li>
          <li>Working knowledge of written English sufficient to read primary literature</li>
          <li>A genuine time commitment of at least the stated hours, for at least six months</li>
          <li>Willingness to write — every member produces text, not only data</li>
          <li>For computational roles: basic programming ability in Python or R</li>
          <li>For laboratory roles: access to, or enrolment at, an institution with a supervised laboratory</li>
        </ul>
        <div class="note-box mt-3">
          <strong>What we do not ask for</strong>
          There is no application fee, no minimum CGPA, and no requirement that you study in Dhaka. Remote participation is supported for every computational role.
        </div>
      </div>

      <div>
        <div class="divider-label">Selection process</div>
        <ol class="steps">
          <li class="step">
            <span class="step-num">01</span>
            <div><h3>Application</h3><p>The form below. We read every submission; the motivation paragraph carries most of the weight.</p></div>
          </li>
          <li class="step">
            <span class="step-num">02</span>
            <div><h3>Written task</h3><p>Shortlisted applicants summarise a supplied paper in 400 words within one week.</p></div>
          </li>
          <li class="step">
            <span class="step-num">03</span>
            <div><h3>Methods conversation</h3><p>A thirty-minute discussion about the paper and your reasoning — not a viva.</p></div>
          </li>
          <li class="step">
            <span class="step-num">04</span>
            <div><h3>Placement</h3><p>An offer naming your project team, mentor, expected output and start date.</p></div>
          </li>
        </ol>
        <p class="muted mt-3" style="font-size:.85rem;">Applications for the 2026–27 cohort close on <strong>30 September 2026</strong>. Volunteer contributor applications are accepted year-round.</p>
      </div>
    </div>
  </div>
</section>

<!-- Application form ------------------------------------------------------>
<section class="section" id="apply">
  <div class="container container--narrow">
    <div class="section-head">
      <span class="kicker">Application</span>
      <h2>Apply for a position</h2>
      <p>Fields marked <span class="required">*</span> are required. You will receive an acknowledgement within five working days.</p>
    </div>

    <?php if ($success): ?>
      <div class="alert alert--ok" role="status">
        <strong>Application received.</strong>
        Thank you — your application has been recorded. We will write to the address you gave within five working days. If you do not hear from us, check your spam folder before writing again.
      </div>
    <?php endif; ?>

    <?php if ($errors): ?>
      <div class="alert alert--error" role="alert">
        <strong>Your application was not submitted.</strong>
        Please correct the following:
        <ul>
          <?php foreach ($errors as $message): ?>
            <li><?= e($message) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form class="form-card" method="post" action="<?= e(url('/join/')) ?>#apply" novalidate>
      <?= csrf_field() ?>
      <div class="honeypot" aria-hidden="true">
        <label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
      </div>

      <div class="form-grid">
        <label class="field">
          <span class="field-label">Full name <span class="required">*</span></span>
          <input class="input <?= isset($errors['full_name']) ? 'field-error' : '' ?>" type="text" name="full_name" value="<?= $val('full_name') ?>" required>
          <?php if (isset($errors['full_name'])): ?><span class="error-text"><?= e($errors['full_name']) ?></span><?php endif; ?>
        </label>

        <label class="field">
          <span class="field-label">E-mail <span class="required">*</span></span>
          <input class="input <?= isset($errors['email']) ? 'field-error' : '' ?>" type="email" name="email" value="<?= $val('email') ?>" required>
          <?php if (isset($errors['email'])): ?><span class="error-text"><?= e($errors['email']) ?></span><?php endif; ?>
        </label>

        <label class="field">
          <span class="field-label">Phone (optional)</span>
          <input class="input" type="tel" name="phone" value="<?= $val('phone') ?>">
        </label>

        <label class="field">
          <span class="field-label">Institution <span class="required">*</span></span>
          <input class="input <?= isset($errors['institution']) ? 'field-error' : '' ?>" type="text" name="institution" value="<?= $val('institution') ?>" required>
          <?php if (isset($errors['institution'])): ?><span class="error-text"><?= e($errors['institution']) ?></span><?php endif; ?>
        </label>

        <label class="field">
          <span class="field-label">Department / programme</span>
          <input class="input" type="text" name="department" value="<?= $val('department') ?>">
        </label>

        <label class="field">
          <span class="field-label">Current level</span>
          <select class="select" name="level">
            <?php foreach (['', 'Undergraduate', 'Master\'s', 'MPhil / PhD', 'Graduated', 'Faculty member'] as $level): ?>
              <option value="<?= e($level) ?>"<?= ($old['level'] ?? '') === $level ? ' selected' : '' ?>><?= $level === '' ? 'Select…' : e($level) ?></option>
            <?php endforeach; ?>
          </select>
        </label>

        <label class="field">
          <span class="field-label">Year of study (optional)</span>
          <input class="input" type="text" name="year" value="<?= $val('year') ?>" placeholder="e.g. 3rd year, 2nd semester">
        </label>

        <label class="field">
          <span class="field-label">Position applied for <span class="required">*</span></span>
          <select class="select <?= isset($errors['position']) ? 'field-error' : '' ?>" name="position" required>
            <option value="">Select…</option>
            <?php foreach ($positions as $p): ?>
              <option value="<?= e($p) ?>"<?= ($old['position'] ?? '') === $p ? ' selected' : '' ?>><?= e($p) ?></option>
            <?php endforeach; ?>
          </select>
          <?php if (isset($errors['position'])): ?><span class="error-text"><?= e($errors['position']) ?></span><?php endif; ?>
        </label>

        <div class="field field--full">
          <span class="field-label">Research domains of interest <span class="required">*</span></span>
          <div class="grid grid-3" style="gap:10px;margin-top:6px;">
            <?php foreach ($domainNames as $domain): ?>
              <label class="check-row">
                <input type="checkbox" name="domains[]" value="<?= e($domain) ?>"<?= in_array($domain, $selectedDomains ?? [], true) ? ' checked' : '' ?>>
                <span><?= e($domain) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
          <?php if (isset($errors['domains'])): ?><span class="error-text"><?= e($errors['domains']) ?></span><?php endif; ?>
        </div>

        <label class="field">
          <span class="field-label">Hours available per week</span>
          <input class="input" type="text" name="hours" value="<?= $val('hours') ?>" placeholder="e.g. 12">
        </label>

        <label class="field">
          <span class="field-label">CV, portfolio or Scholar link (optional)</span>
          <input class="input" type="url" name="portfolio" value="<?= $val('portfolio') ?>" placeholder="https://">
        </label>

        <label class="field field--full">
          <span class="field-label">Relevant skills &amp; experience</span>
          <textarea class="textarea" name="skills" style="min-height:100px;" placeholder="Laboratory techniques, programming languages, statistical software, prior projects…"><?= $val('skills') ?></textarea>
        </label>

        <label class="field field--full">
          <span class="field-label">Why do you want to join, and what do you want to work on? <span class="required">*</span></span>
          <textarea class="textarea <?= isset($errors['motivation']) ? 'field-error' : '' ?>" name="motivation" required placeholder="Be specific. A paragraph about a question you find genuinely interesting tells us more than a list of achievements."><?= $val('motivation') ?></textarea>
          <span class="hint">Minimum 80 characters. This is the part of the application we weight most heavily.</span>
          <?php if (isset($errors['motivation'])): ?><span class="error-text"><?= e($errors['motivation']) ?></span><?php endif; ?>
        </label>

        <label class="field field--full">
          <span class="field-label">How did you hear about us? (optional)</span>
          <input class="input" type="text" name="referral" value="<?= $val('referral') ?>">
        </label>

        <div class="field field--full">
          <label class="check-row">
            <input type="checkbox" name="consent" value="1"<?= !empty($_POST['consent']) && $errors ? ' checked' : '' ?>>
            <span>I confirm the information above is accurate and I consent to Neurobridge Research storing it for the purpose of assessing this application. <span class="required">*</span></span>
          </label>
          <?php if (isset($errors['consent'])): ?><span class="error-text"><?= e($errors['consent']) ?></span><?php endif; ?>
        </div>
      </div>

      <div class="btn-row" style="margin-top:8px;">
        <button class="btn btn-primary" type="submit">Submit application</button>
        <a class="btn btn-outline" href="<?= e(url('/contact/')) ?>">Ask a question first</a>
      </div>
    </form>
  </div>
</section>

<!-- FAQ ------------------------------------------------------------------->
<section class="section section--surface">
  <div class="container container--narrow">
    <div class="section-head">
      <span class="kicker">FAQ</span>
      <h2>Questions we are asked most</h2>
    </div>

    <div class="faq">
      <details open>
        <summary>Is there any fee to join?</summary>
        <div class="faq-body">No. There is no application fee, no membership fee and no training fee. If anyone asks you to pay to join Neurobridge, it is not us — please report it to <a href="mailto:<?= e($SITE['contact']['email']) ?>"><?= e($SITE['contact']['email']) ?></a>.</div>
      </details>
      <details>
        <summary>Are the positions paid?</summary>
        <div class="faq-body">Positions are unpaid. What the organisation covers instead is computational access, article processing charges where they apply, conference registration for accepted work, and supervision. We say this plainly so nobody applies expecting a salary.</div>
      </details>
      <details>
        <summary>I am not in Dhaka. Can I still participate?</summary>
        <div class="faq-body">Yes, for every computational role and for most writing and curation work. Laboratory roles need physical access to a supervised laboratory, which we arrange through partner departments where we can.</div>
      </details>
      <details>
        <summary>I have no research experience at all. Should I apply?</summary>
        <div class="faq-body">Yes. Roughly half of each intake has never worked on a research project. What matters is that you can commit the hours and are willing to be taught — including being told your first draft needs rewriting.</div>
      </details>
      <details>
        <summary>Will I be an author on a paper?</summary>
        <div class="faq-body">If you contribute substantively to design, execution or analysis, and you approve the final manuscript, yes. Authorship criteria are agreed in writing at the start of a project. Attendance alone does not earn authorship.</div>
      </details>
      <details>
        <summary>Can you help with my applications for graduate study abroad?</summary>
        <div class="faq-body">Higher-study guidance is part of the fellowship track from the third quarter onwards, and alumni run open panels several times a year. We do not act as an admissions consultancy and we do not guarantee outcomes.</div>
      </details>
      <details>
        <summary>What happens if I need to leave early?</summary>
        <div class="faq-body">Tell your mentor as soon as you know. We would rather hand the workstream over cleanly than lose it. Members who leave in good standing keep their authorship and are welcome to return.</div>
      </details>
      <details>
        <summary>Do you accept international applicants?</summary>
        <div class="faq-body">Yes, for remote roles. Time-zone overlap of at least three hours with GMT+6 makes supervision workable.</div>
      </details>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
