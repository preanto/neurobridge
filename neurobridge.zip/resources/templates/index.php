<?php
/** Writing templates and manuscript guidelines. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Writing Templates';
$page_description = 'LaTeX, Overleaf and Word templates for manuscripts, theses, posters and ethics submissions, plus citation style files from Neurobridge Research.';

$templates = $RESOURCES['templates'];

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Writing templates & guidelines';
$ph_lead   = 'The templates our own members write in. Using them is not compulsory, but every internal review assumes the structure they enforce.';
$ph_crumbs = [['label' => 'Resources', 'path' => '/resources/'], ['label' => 'Templates']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/resources-subnav.php';
?>

<section class="section">
  <div class="container">
    <div class="grid grid-2">
      <?php foreach ($templates as $t): ?>
        <article class="card card--pad-lg">
          <div class="badge-group" style="margin-bottom:14px;">
            <span class="badge badge--brand"><?= e($t['format']) ?></span>
            <span class="badge badge--outline"><?= e($t['version']) ?></span>
          </div>

          <h3><?= e($t['title']) ?></h3>
          <p><?= e($t['summary']) ?></p>

          <div style="margin-top:6px;">
            <span class="field-label">Package contents</span>
            <div class="tag-row" style="margin-top:0;">
              <?php foreach ($t['includes'] as $file): ?>
                <span class="badge"><?= e($file) ?></span>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="card-foot">
            <div class="btn-row">
              <a class="btn btn-primary btn-sm" href="<?= e($t['url']) ?>"><?= icon('download', 'ico') ?> Download</a>
              <?php if (!empty($t['overleaf'])): ?>
                <a class="btn btn-outline btn-sm" href="<?= e($t['overleaf']) ?>" target="_blank" rel="noopener"><?= icon('external', 'ico') ?> Open in Overleaf</a>
              <?php endif; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">Writing guidance</span>
        <h2>Before you open the template</h2>
        <p>Most manuscripts that fail internal review fail for the same reasons: the research question is not stated as a question, the methods cannot be reproduced from the text, and the discussion argues beyond what the results support.</p>
        <p>Write the methods first, then the results, then the introduction, and the abstract last. The template is ordered for the reader; it does not have to be filled in that order.</p>
      </div>

      <div class="faq">
        <details>
          <summary>Which template should I use for a thesis?</summary>
          <div class="faq-body">Use the Undergraduate Thesis Template, then check your university's formatting circular for margin, line-spacing and declaration-page requirements — those vary between institutions and the template notes where to change them.</div>
        </details>
        <details>
          <summary>Can I use these templates outside Neurobridge?</summary>
          <div class="faq-body">Yes. They are released for anyone to use, including students who have no connection to the group. Attribution is appreciated but not required.</div>
        </details>
        <details>
          <summary>Do I have to write in LaTeX?</summary>
          <div class="faq-body">No. The Word versions carry the same structure and styles. Choose LaTeX if your manuscript is equation-heavy or the target journal supplies a class file; otherwise Word is entirely acceptable.</div>
        </details>
        <details>
          <summary>How do I cite a dataset or a piece of software?</summary>
          <div class="faq-body">Follow the Reference &amp; Citation Style Guide — it covers datasets, software releases, preprints and clinical trial registrations, with worked examples in both Vancouver and APA 7.</div>
        </details>
        <details>
          <summary>Who reviews my draft?</summary>
          <div class="faq-body">Two internal reviewers: your faculty mentor for methodology, and one member from outside the project team for clarity and argument. Both reviews are written and returned within ten working days.</div>
        </details>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
