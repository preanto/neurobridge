<?php
/** Open-source repositories. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Code & Repositories';
$page_description = 'Open-source pipelines, algorithms, models and analysis toolkits published by Neurobridge Research on GitHub.';

$repos   = $RESOURCES['repositories'];
$fDomain = query('domain');
$domains = column_options($repos, 'domains');

$filtered = $fDomain === ''
    ? $repos
    : array_values(array_filter($repos, fn ($r) => in_array($fDomain, $r['domains'], true)));

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Code & repositories';
$ph_lead   = 'The code behind our published results. Each repository is documented, licensed, and tagged at the version used for the corresponding paper.';
$ph_crumbs = [['label' => 'Resources', 'path' => '/resources/'], ['label' => 'Code & Repositories']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/resources-subnav.php';
?>

<section class="section">
  <div class="container">

    <form class="filter-bar" method="get" data-autosubmit>
      <div class="filter-grid">
        <div>
          <label class="field-label" for="domain">Research domain</label>
          <select class="select" name="domain" id="domain">
            <option value="">All domains</option>
            <?php foreach ($domains as $d): ?>
              <option value="<?= e($d) ?>"<?= $fDomain === $d ? ' selected' : '' ?>><?= e($d) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="filter-actions">
          <button class="btn btn-primary btn-sm" type="submit">Apply</button>
          <a class="btn btn-outline btn-sm" href="<?= e(url('/resources/github/')) ?>">Reset</a>
        </div>
      </div>
    </form>

    <p class="result-count">Showing <?= e((string) count($filtered)) ?> of <?= e((string) count($repos)) ?> repositories</p>

    <div class="grid grid-2">
      <?php foreach ($filtered as $r): ?>
        <article class="card card--pad-lg">
          <div class="badge-group" style="margin-bottom:14px;">
            <span class="badge badge--brand"><?= e($r['language']) ?></span>
            <span class="badge badge--outline"><?= e($r['licence']) ?></span>
            <span class="badge">★ <?= e((string) $r['stars']) ?></span>
          </div>

          <h3><?= e($r['title']) ?></h3>
          <p class="code-snippet" style="margin:0 0 14px;">github.com/neurobridge-research/<?= e($r['name']) ?></p>
          <p><?= e($r['summary']) ?></p>

          <div class="tag-row">
            <?php foreach ($r['domains'] as $d): ?>
              <span class="badge"><?= e($d) ?></span>
            <?php endforeach; ?>
          </div>

          <div class="card-foot" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
            <a class="btn btn-outline btn-sm" href="<?= e($r['url']) ?>" target="_blank" rel="noopener">
              <?= icon('external', 'ico') ?> View repository
            </a>
            <span class="muted" style="font-size:.78rem;">Updated <?= e($r['updated']) ?></span>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="grid grid-3">
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('check') ?></div>
        <h3>What we guarantee</h3>
        <p>Each repository contains a README with the exact commands used, an environment specification, and the version tag that produced the published figures.</p>
      </div>
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('users') ?></div>
        <h3>Contributions welcome</h3>
        <p>Issues and pull requests are read. If you have adapted a pipeline for a different organism, dataset or platform, we would like the patch.</p>
      </div>
      <div class="card card--flat">
        <div class="icon-badge"><?= icon('document') ?></div>
        <h3>Citing the code</h3>
        <p>Every release is archived with a DOI. Cite the archived release rather than the repository URL so the version is unambiguous.</p>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
