<?php
/** Resources overview. */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$page_title       = 'Resources';
$page_description = 'Open datasets, analysis repositories and manuscript templates released by Neurobridge Research for the wider research community.';

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Research resources';
$ph_lead   = 'Everything we can release, we release. Datasets, analysis code and the writing templates our own members use are published here for anyone to reuse with attribution.';
$ph_crumbs = [['label' => 'Resources']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/resources-subnav.php';
?>

<section class="section">
  <div class="container">
    <div class="grid grid-3">
      <a class="card card--pad-lg" href="<?= e(url('/resources/datasets/')) ?>" style="text-decoration:none;">
        <div class="icon-badge"><?= icon('database') ?></div>
        <h3>Datasets</h3>
        <p>Medical, tabular, sequence and biosignal datasets deposited on Mendeley Data, Zenodo, PhysioNet and NCBI — each with a ready-to-paste citation snippet.</p>
        <div class="card-foot"><span class="arrow-link"><?= e((string) count($RESOURCES['datasets'])) ?> datasets</span></div>
      </a>
      <a class="card card--pad-lg" href="<?= e(url('/resources/github/')) ?>" style="text-decoration:none;">
        <div class="icon-badge"><?= icon('code') ?></div>
        <h3>Code &amp; repositories</h3>
        <p>Open-source pipelines, models and analysis toolkits — the same code used to produce our published results, with licences and documentation.</p>
        <div class="card-foot"><span class="arrow-link"><?= e((string) count($RESOURCES['repositories'])) ?> repositories</span></div>
      </a>
      <a class="card card--pad-lg" href="<?= e(url('/resources/templates/')) ?>" style="text-decoration:none;">
        <div class="icon-badge"><?= icon('document') ?></div>
        <h3>Writing templates</h3>
        <p>LaTeX, Overleaf and Word templates for manuscripts, theses, posters and ethics submissions, plus the group's citation style files.</p>
        <div class="card-foot"><span class="arrow-link"><?= e((string) count($RESOURCES['templates'])) ?> templates</span></div>
      </a>
    </div>
  </div>
</section>

<section class="section section--surface">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">Working guidelines</span>
        <h2>The rules our resources are built around</h2>
        <p>These are the standing policies every project follows. They are published here because they are also the answer to most questions new members ask.</p>
      </div>
      <div>
        <ul class="info-list">
          <?php foreach ($RESOURCES['guidelines'] as $g): ?>
            <li>
              <span class="label"><?= e(explode(' ', $g['title'])[0]) ?></span>
              <span class="value"><strong><?= e($g['title']) ?>.</strong> <?= e($g['text']) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-head section-head--center">
      <span class="kicker">Reuse</span>
      <h2>Using our material</h2>
      <p>Datasets and code are released under the licence stated on each item. Attribution is required; commercial reuse is permitted only where the licence allows it. If a resource is useful to you, we would like to hear about it.</p>
      <div class="btn-row" style="justify-content:center;margin-top:24px;">
        <a class="btn btn-primary" href="<?= e(url('/contact/')) ?>">Get in touch</a>
        <a class="btn btn-outline" href="<?= e(url('/publications/')) ?>">See the related publications</a>
      </div>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
