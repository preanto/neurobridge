<?php
/** Datasets released by the group. */
declare(strict_types=1);
require __DIR__ . '/../../includes/bootstrap.php';

$page_title       = 'Datasets';
$page_description = 'Open medical, sequence, tabular and biosignal datasets released by Neurobridge Research on Mendeley Data, Zenodo, PhysioNet and NCBI, with citation snippets.';

$datasets = $RESOURCES['datasets'];

$fDomain = query('domain');
$fRepo   = query('repo');

$domains = column_options($datasets, 'domains');
$repos   = column_options($datasets, 'repo');

$filtered = array_values(array_filter($datasets, static function (array $d) use ($fDomain, $fRepo): bool {
    if ($fDomain !== '' && !in_array($fDomain, $d['domains'], true)) { return false; }
    if ($fRepo !== '' && $d['repo'] !== $fRepo)                      { return false; }
    return true;
}));

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Datasets';
$ph_lead   = 'Every dataset here is deposited in a public repository with a persistent identifier. Clinical data are de-identified and released only where participant consent covers secondary research use.';
$ph_crumbs = [['label' => 'Resources', 'path' => '/resources/'], ['label' => 'Datasets']];
require APP_ROOT . '/includes/partials/page-header.php';
require APP_ROOT . '/includes/partials/resources-subnav.php';
?>

<section class="section">
  <div class="container">

    <form class="filter-bar" method="get" data-autosubmit>
      <div class="filter-grid">
        <div>
          <label class="field-label" for="repo">Repository</label>
          <select class="select" name="repo" id="repo">
            <option value="">All repositories</option>
            <?php foreach ($repos as $r): ?>
              <option value="<?= e($r) ?>"<?= $fRepo === $r ? ' selected' : '' ?>><?= e($r) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="field-label" for="domain">Research domain</label>
          <select class="select" name="domain" id="domain">
            <option value="">All domains</option>
            <?php foreach ($domains as $d): ?>
              <option value="<?= e($d) ?>"<?= $fDomain === $d ? ' selected' : '' ?>><?= e($d) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="filter-actions">
          <button class="btn btn-primary btn-sm" type="submit">Apply</button>
          <a class="btn btn-outline btn-sm" href="<?= e(url('/resources/datasets/')) ?>">Reset</a>
        </div>
      </div>
    </form>

    <p class="result-count">Showing <?= e((string) count($filtered)) ?> of <?= e((string) count($datasets)) ?> datasets</p>

    <?php if (!$filtered): ?>
      <div class="empty-state"><p>No datasets match these filters.</p></div>
    <?php else: ?>
      <div class="grid grid-2">
        <?php foreach ($filtered as $d): ?>
          <article class="card card--pad-lg">
            <div class="badge-group" style="margin-bottom:14px;">
              <span class="badge badge--brand"><?= e($d['repo']) ?></span>
              <span class="badge"><?= e((string) $d['year']) ?></span>
              <span class="badge badge--outline"><?= e($d['licence']) ?></span>
            </div>

            <h3><?= e($d['title']) ?></h3>
            <p><?= e($d['summary']) ?></p>

            <ul class="info-list" style="margin-top:8px;">
              <li><span class="label">Accession</span><span class="value"><?= e($d['accession']) ?></span></li>
              <li><span class="label">Contents</span><span class="value"><?= e($d['size']) ?></span></li>
            </ul>

            <div style="margin-top:16px;">
              <span class="field-label">Cite as</span>
              <div class="code-snippet"><?= e($d['citation']) ?></div>
            </div>

            <div class="tag-row">
              <?php foreach ($d['domains'] as $dom): ?>
                <span class="badge"><?= e($dom) ?></span>
              <?php endforeach; ?>
            </div>

            <div class="card-foot">
              <a class="btn btn-outline btn-sm" href="<?= e($d['url']) ?>" target="_blank" rel="noopener">
                <?= icon('external', 'ico') ?> Open in <?= e($d['repo']) ?>
              </a>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="note-box" style="margin-top:44px;">
      <strong>Requesting restricted data</strong>
      Datasets marked with a restricted licence require a short data-use agreement and, for clinical records, evidence of ethical approval at your institution. Write to
      <a href="mailto:<?= e($SITE['contact']['email']) ?>"><?= e($SITE['contact']['email']) ?></a> describing the intended analysis.
    </div>

  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
