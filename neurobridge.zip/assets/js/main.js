/* ===========================================================================
   Neurobridge Research — minimal progressive enhancement.
   Everything here is optional: the site works without JavaScript.
   =========================================================================== */
(function () {
  'use strict';

  /* --- Mobile navigation ------------------------------------------------ */
  var toggle = document.getElementById('navToggle');
  var panel  = document.getElementById('mobileNav');

  if (toggle && panel) {
    toggle.addEventListener('click', function () {
      var open = panel.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    // Close the panel when a link is followed or the viewport grows.
    panel.addEventListener('click', function (event) {
      if (event.target.closest('a')) {
        panel.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 1080 && panel.classList.contains('is-open')) {
        panel.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* --- News ticker: duplicate the track so the loop is seamless --------- */
  var track = document.querySelector('.ticker-track');
  if (track && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    track.innerHTML += track.innerHTML;
  }

  /* --- Filter forms: submit on change (falls back to the Apply button) -- */
  document.querySelectorAll('[data-autosubmit]').forEach(function (form) {
    form.querySelectorAll('select').forEach(function (select) {
      select.addEventListener('change', function () { form.submit(); });
    });
  });

  /* --- Client-side keyword filter for simple card lists ----------------- */
  var listFilter = document.querySelector('[data-filter-input]');
  if (listFilter) {
    var targets = document.querySelectorAll('[data-filter-item]');
    var counter = document.querySelector('[data-filter-count]');

    listFilter.addEventListener('input', function () {
      var term    = listFilter.value.trim().toLowerCase();
      var visible = 0;

      targets.forEach(function (item) {
        var match = term === '' || item.textContent.toLowerCase().indexOf(term) !== -1;
        item.style.display = match ? '' : 'none';
        if (match) { visible++; }
      });

      if (counter) {
        counter.textContent = visible + (visible === 1 ? ' result' : ' results');
      }
    });
  }
})();
