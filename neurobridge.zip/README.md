# Neurobridge Research — website

A PHP + HTML + CSS website for a bioscience research and training organisation.
No framework, no build step, no database — plain PHP files, one stylesheet, one
small JavaScript file. Typography is Montserrat throughout (weights 300–700).

---

## 1. Running it

**Requirements:** PHP 8.0 or newer. Any web server (Apache, nginx, IIS) or PHP's
own built-in server.

### Quick start with the built-in server

```
cd "d:\Work Files Only\Website Orders\Neurobridge"
php -S localhost:8000
```

Then open <http://localhost:8000>.

### XAMPP / WAMP / Laragon

Copy the whole folder into `htdocs` (XAMPP) or `www` (WAMP/Laragon) and open
`http://localhost/Neurobridge/`. The site detects that it is running in a
sub-folder and builds its links accordingly — no configuration needed.

### Live hosting

Upload everything to the document root. Make sure `storage/` is writable by PHP
(`chmod 775 storage/submissions` on Linux hosts) and set `APP_DEBUG` to `false`
in `includes/config.php`.

---

## 2. Structure

```
/
├── index.php                   Home
├── 404.php                     Error page
├── .htaccess                   Apache: clean errors, caching, security headers
│
├── research/                   Research overview and domains
├── team/                       Team overview
│   ├── researchers/            PI, faculty, associates, undergraduate RAs
│   ├── fellows/                Research fellows
│   ├── collaborators/          International faculty and clinical mentors
│   ├── scholars/               Wall of Scholars (filterable)
│   ├── committee/              Advisory, steering and ethics committees
│   └── alumni/                 Past members
├── publications/               Publications overview
│   ├── journal/                Journal articles (filterable)
│   └── conference/             Conference papers (filterable)
├── events/                     Workshops, seminars, MoUs, milestones
├── resources/                  Resources overview
│   ├── datasets/               Datasets with citation snippets
│   ├── github/                 Code repositories
│   └── templates/              LaTeX / Word / Overleaf templates
├── join/                       Recruitment: criteria, application form, FAQs
├── contact/                    Contact details and enquiry form
│
├── assets/
│   ├── css/style.css           The entire design system
│   ├── js/main.js              Mobile nav, ticker, filters (optional)
│   └── img/                    Logo, light logo, favicon (SVG)
│
├── includes/
│   ├── bootstrap.php           Loads config, helpers and all content
│   ├── config.php              Site settings, navigation, mail options
│   ├── functions.php           Helpers: escaping, URLs, filters, form storage
│   ├── icons.php               Inline SVG icon set
│   ├── header.php              <head>, top bar, masthead, navigation
│   ├── footer.php              Footer and closing markup
│   ├── partials/               Page header + section sub-navigations
│   └── data/                   ► ALL WEBSITE CONTENT LIVES HERE ◄
│       ├── site.php            Identity, mission, vision, metrics, testimonials
│       ├── research.php        Domains, focus areas, pipeline, facilities
│       ├── team.php            People and the Wall of Scholars
│       ├── publications.php    Journal + conference records
│       ├── events.php          Upcoming, past events and milestones
│       ├── resources.php       Datasets, repositories, templates, guidelines
│       └── news.php            Ticker / latest news items
│
└── storage/submissions/        Form submissions, written as JSON
```

---

## 3. Editing content

Everything a non-developer needs to change is in `includes/data/`. Each file is
a plain PHP array with comments explaining the fields. For example, adding a
journal article means appending one block to `includes/data/publications.php`:

```php
[
    'title'   => 'Your article title',
    'authors' => 'Rahman MA, **Siddique TH**',   // ** ** = lab member, shown bold
    'year'    => 2026,
    'venue'   => 'Journal name',
    'detail'  => 'Vol. 12, pp. 1–10',
    'indexes' => ['Scopus', 'SCIE', 'Q1'],       // these drive the filters
    'doi'     => '10.1000/example',              // bare DOI, no https://
    'domains' => ['Bioinformatics'],
    'open'    => true,
],
```

The year, index and domain filter menus build themselves from the data — you
never edit the filter lists.

**Contact details, address, e-mail, social links, mission and vision** are in
`includes/data/site.php`.
**The navigation menu** is the `$NAV` array in `includes/config.php`.

> ### ⚠ Sample content
> All names, publications, DOIs, datasets, dates, figures and quotations
> shipped with this template are **realistic placeholders**, not real records.
> Replace them before publishing. Where real people appear (team, alumni, Wall
> of Scholars, testimonials), get written consent before showing names,
> photographs, e-mail addresses, admission results or funding details.

---

## 4. Forms

`/join` and `/contact` both post to themselves and are protected by a CSRF
token, a honeypot field and server-side validation. Every valid submission is
written as a timestamped JSON file to `storage/submissions/`.

To also receive e-mail notifications, open `includes/config.php` and set:

```php
const MAIL_NOTIFY = true;
const MAIL_TO     = 'your-address@example.org';
```

This uses PHP's `mail()`. On hosts where `mail()` is unreliable, replace the
call in `store_submission()` (`includes/functions.php`) with PHPMailer or an
API-based sender — it is a single function to change.

`storage/` is blocked from HTTP access by `.htaccess`. On nginx, add:

```
location ^~ /storage/  { deny all; }
location ^~ /includes/ { deny all; }
```

---

## 5. Design notes

- **Type:** Montserrat only — 300/400 body, 500/600 UI and labels, 600/700 headings.
- **Colour:** a single deep-teal brand ramp plus neutral greys; amber is used
  sparingly for quartile badges. All tokens are CSS custom properties at the top
  of `assets/css/style.css` — change `--brand` and the whole site follows.
- **Motion:** deliberately minimal. Hover colour changes, and one horizontal
  news ticker which pauses on hover and is disabled entirely under
  `prefers-reduced-motion`.
- **Photography:** none required. People are shown as initial avatars in six
  rotating tints; event covers are CSS gradients. To use real photographs, add
  an `'photo' => '/assets/img/team/name.jpg'` key to a person and swap the
  `avatar()` call in the relevant page for an `<img>`.
- **Accessibility:** skip link, visible focus rings, semantic landmarks,
  breadcrumbs, labelled form fields with inline error text, and a colour
  contrast target of at least 4.5:1 for body text.
- **No JavaScript required:** filters are server-side (`GET` parameters), the
  FAQ uses native `<details>`, and the mobile menu is the only feature that
  needs JS.

---

## 6. Things to do before going live

1. Replace all sample content in `includes/data/`.
2. Update the address, phone number and e-mail addresses in `site.php`.
3. Replace the placeholder social and repository URLs.
4. Point the template download links (`resources.php` → `'url'`) at real files.
5. Swap the map placeholder in `contact/index.php` for an embedded map.
6. Set `APP_DEBUG = false` in `includes/config.php`.
7. Confirm `storage/submissions/` is writable and not publicly reachable.
8. Add a privacy notice if you collect applicant data in your jurisdiction.
