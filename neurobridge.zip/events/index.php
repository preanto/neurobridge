<?php
/** Events: workshops, seminars, MoU signings and conference organisation. */
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

$page_title       = 'Events';
$page_description = 'Workshops, seminars, MoU signings and conferences organised or co-hosted by Neurobridge Research, with event galleries and milestones.';

$fType = query('type');
$types = column_options($EVENTS['past'], 'type');

$past = $EVENTS['past'];
if ($fType !== '') {
    $past = array_values(array_filter($past, fn ($ev) => $ev['type'] === $fType));
}

require APP_ROOT . '/includes/header.php';

$ph_title  = 'Events, workshops & MoUs';
$ph_lead   = 'Training events, invited seminars, partnership signings and the conferences we organise. Registration for public events is announced here and on our mailing list.';
$ph_crumbs = [['label' => 'Events']];
require APP_ROOT . '/includes/partials/page-header.php';
?>

<!-- Upcoming -------------------------------------------------------------->
<section class="section">
  <div class="container">
    <div class="section-head">
      <span class="kicker">Upcoming</span>
      <h2>What is coming next</h2>
      <p>Places on training events are limited. Students from universities outside Dhaka are given priority and fee waivers where a fee applies.</p>
    </div>

    <div class="grid grid-3">
      <?php foreach ($EVENTS['upcoming'] as $ev): ?>
        <article class="event-card">
          <div class="event-cover"><span class="badge"><?= e($ev['type']) ?></span></div>
          <div class="event-body">
            <div class="event-date"><?= icon('calendar', 'ico') ?> <?= e($ev['date_text']) ?></div>
            <h3><?= e($ev['title']) ?></h3>
            <div class="event-venue"><?= icon('pin', 'ico') ?><span><?= e($ev['venue']) ?></span></div>
            <p><?= e($ev['summary']) ?></p>
            <div class="tag-row">
              <?php foreach ($ev['tags'] as $tag): ?>
                <span class="badge"><?= e($tag) ?></span>
              <?php endforeach; ?>
            </div>
            <div class="card-foot">
              <a class="btn btn-outline btn-sm" href="<?= e(url($ev['cta']['url'])) ?>"><?= e($ev['cta']['label']) ?></a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Past events ----------------------------------------------------------->
<section class="section section--surface">
  <div class="container">
    <div class="section-head section-head--split">
      <div>
        <span class="kicker">Archive</span>
        <h2>Past events &amp; galleries</h2>
        <p>Photographs from each event are held in the gallery. Contact us if you need a high-resolution image or a certificate reissued.</p>
      </div>
      <form method="get" data-autosubmit style="min-width:220px;">
        <label class="field-label" for="type">Filter by type</label>
        <select class="select" name="type" id="type">
          <option value="">All event types</option>
          <?php foreach ($types as $t): ?>
            <option value="<?= e($t) ?>"<?= $fType === $t ? ' selected' : '' ?>><?= e($t) ?></option>
          <?php endforeach; ?>
        </select>
        <noscript><button class="btn btn-primary btn-sm" type="submit" style="margin-top:10px;">Filter</button></noscript>
      </form>
    </div>

    <?php if (!$past): ?>
      <div class="empty-state"><p>No events of this type yet.</p></div>
    <?php else: ?>
      <ul class="event-list">
        <?php foreach ($past as $ev): ?>
          <li class="event-item">
            <div class="when">
              <?= e($ev['date_text']) ?>
              <small><?= e($ev['type']) ?></small>
            </div>
            <div>
              <h3><?= e($ev['title']) ?></h3>
              <div class="event-venue"><?= icon('pin', 'ico') ?><span><?= e($ev['venue']) ?></span></div>
              <p><?= e($ev['summary']) ?></p>
              <div class="tag-row">
                <?php foreach ($ev['tags'] as $tag): ?>
                  <span class="badge badge--brand"><?= e($tag) ?></span>
                <?php endforeach; ?>
              </div>
              <?php if (!empty($ev['photos'])): ?>
                <div class="gallery-strip" aria-label="Event gallery">
                  <?php for ($i = 1; $i <= min(5, (int) $ev['photos']); $i++): ?>
                    <span class="gallery-thumb"><?= e(sprintf('%02d', $i)) ?></span>
                  <?php endfor; ?>
                  <span class="gallery-more"><?= e((string) $ev['photos']) ?> photos</span>
                </div>
              <?php endif; ?>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</section>

<!-- Milestones ------------------------------------------------------------>
<section class="section">
  <div class="container">
    <div class="split">
      <div>
        <span class="kicker">Milestones</span>
        <h2>How the organisation has grown</h2>
        <p>Neurobridge began as a seven-member reading group in 2021. The milestones below mark the points at which its scope changed.</p>
        <div class="btn-row mt-3">
          <a class="btn btn-primary" href="<?= e(url('/contact/')) ?>">Partner with us</a>
          <a class="btn btn-outline" href="<?= e(url('/team/collaborators/')) ?>">Current collaborators</a>
        </div>
      </div>

      <ol class="timeline">
        <?php foreach ($EVENTS['milestones'] as $m): ?>
          <li>
            <span class="t-year"><?= e($m['year']) ?></span>
            <h3><?= e($m['title']) ?></h3>
            <p><?= e($m['text']) ?></p>
          </li>
        <?php endforeach; ?>
      </ol>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/includes/footer.php'; ?>
