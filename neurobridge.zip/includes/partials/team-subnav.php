<?php
/** Sub-navigation shared by every /team page. */
declare(strict_types=1);

if (!defined('APP_ROOT')) {
    exit('Direct access is not permitted.');
}

$teamLinks = [
    '/team/'               => 'Overview',
    '/team/researchers/'   => 'Researchers',
    '/team/fellows/'       => 'Research Fellows',
    '/team/collaborators/' => 'Collaborators',
    '/team/scholars/'      => 'Wall of Scholars',
    '/team/committee/'     => 'Committee',
    '/team/alumni/'        => 'Alumni',
];
?>
<div class="subnav-wrap">
  <div class="container">
    <nav class="subnav" aria-label="Team sections">
      <?php foreach ($teamLinks as $path => $label): ?>
        <a class="<?= is_active($path) ? 'is-active' : '' ?>" href="<?= e(url($path)) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </div>
</div>
