<?php
/** Sub-navigation shared by every /publications page. */
declare(strict_types=1);

if (!defined('APP_ROOT')) {
    exit('Direct access is not permitted.');
}

$pubLinks = [
    '/publications/'            => 'Overview',
    '/publications/journal/'    => 'Journal Articles',
    '/publications/conference/' => 'Conference Papers',
];
?>
<div class="subnav-wrap">
  <div class="container">
    <nav class="subnav" aria-label="Publication sections">
      <?php foreach ($pubLinks as $path => $label): ?>
        <a class="<?= is_active($path) ? 'is-active' : '' ?>" href="<?= e(url($path)) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </div>
</div>
