<?php
/** Sub-navigation shared by every /resources page. */
declare(strict_types=1);

if (!defined('APP_ROOT')) {
    exit('Direct access is not permitted.');
}

$resourceLinks = [
    '/resources/'           => 'Overview',
    '/resources/datasets/'  => 'Datasets',
    '/resources/github/'    => 'Code &amp; Repositories',
    '/resources/templates/' => 'Writing Templates',
];
?>
<div class="subnav-wrap">
  <div class="container">
    <nav class="subnav" aria-label="Resource sections">
      <?php foreach ($resourceLinks as $path => $label): ?>
        <a class="<?= is_active($path) ? 'is-active' : '' ?>" href="<?= e(url($path)) ?>"><?= $label ?></a>
      <?php endforeach; ?>
    </nav>
  </div>
</div>
