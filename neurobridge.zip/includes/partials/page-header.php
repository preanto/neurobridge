<?php
/**
 * Interior page header with breadcrumbs.
 *
 * Expects:
 *   $ph_title  — heading text
 *   $ph_lead   — short introduction (optional)
 *   $ph_crumbs — [['label' => 'Team', 'path' => '/team/'], ['label' => 'Alumni']]
 */
declare(strict_types=1);

if (!defined('APP_ROOT')) {
    exit('Direct access is not permitted.');
}

$ph_crumbs = $ph_crumbs ?? [];
$ph_lead   = $ph_lead ?? '';
?>
<section class="page-header">
  <div class="container">
    <?php if ($ph_crumbs): ?>
      <nav aria-label="Breadcrumb">
        <ol class="breadcrumb">
          <li><a href="<?= e(url('/')) ?>">Home</a></li>
          <?php foreach ($ph_crumbs as $crumb): ?>
            <li>
              <?php if (!empty($crumb['path'])): ?>
                <a href="<?= e(url($crumb['path'])) ?>"><?= e($crumb['label']) ?></a>
              <?php else: ?>
                <span aria-current="page"><?= e($crumb['label']) ?></span>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ol>
      </nav>
    <?php endif; ?>

    <h1><?= e($ph_title) ?></h1>
    <?php if ($ph_lead !== ''): ?>
      <p><?= e($ph_lead) ?></p>
    <?php endif; ?>
  </div>
</section>
<?php
// Reset so a later include cannot inherit stale values.
$ph_crumbs = [];
$ph_lead   = '';
