<?php
/**
 * Site configuration.
 * ---------------------------------------------------------------------------
 * Edit the values in this file (and the arrays in includes/data/) to update
 * the website. No other file needs to be touched for routine content changes.
 */

declare(strict_types=1);

// --- Environment ------------------------------------------------------------
// Set to false on a live server so PHP notices are not printed to visitors.
const APP_DEBUG = true;

if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

date_default_timezone_set('Asia/Dhaka');

// --- Base URL ---------------------------------------------------------------
// Works whether the site lives at the domain root or inside a sub-folder
// (e.g. http://localhost/Neurobridge/).
$__docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
$__appRoot = realpath(APP_ROOT);
$__base    = '';

if ($__docRoot !== false && $__appRoot !== false) {
    $__docRoot = rtrim(str_replace('\\', '/', $__docRoot), '/');
    $__appRoot = rtrim(str_replace('\\', '/', $__appRoot), '/');
    if ($__docRoot !== '' && strpos($__appRoot, $__docRoot) === 0) {
        $__base = substr($__appRoot, strlen($__docRoot));
    }
}

define('BASE_URL', rtrim($__base, '/'));

// --- Form handling ----------------------------------------------------------
// Every submission is written to /storage/submissions/*.json.
// Set MAIL_NOTIFY to true only if the hosting account has a working mail().
const MAIL_NOTIFY  = false;
const MAIL_TO      = 'research@neurobridge.org';
const STORAGE_PATH = APP_ROOT . '/storage/submissions';

// --- Navigation -------------------------------------------------------------
$NAV = [
    ['label' => 'Home',         'path' => '/'],
    ['label' => 'Research',     'path' => '/research/'],
    [
        'label' => 'Team',
        'path'  => '/team/',
        // 'children' => [
        //     ['label' => 'Researchers',    'path' => '/team/researchers/'],
        //     ['label' => 'Research Fellows', 'path' => '/team/fellows/'],
        //     ['label' => 'Collaborators',  'path' => '/team/collaborators/'],
        //     ['label' => 'Wall of Scholars', 'path' => '/team/scholars/'],
        //     ['label' => 'Committee',      'path' => '/team/committee/'],
        //     ['label' => 'Alumni',         'path' => '/team/alumni/'],
        // ],
    ],
    [
        'label' => 'Publications',
        'path'  => '/publications/',
        'children' => [
            ['label' => 'Journal Articles', 'path' => '/publications/journal/'],
            ['label' => 'Conference Papers', 'path' => '/publications/conference/'],
        ],
    ],
    ['label' => 'Events', 'path' => '/events/'],
    [
        'label' => 'Resources',
        'path'  => '/resources/',
        'children' => [
            ['label' => 'Datasets',  'path' => '/resources/datasets/'],
            ['label' => 'Code & Repositories', 'path' => '/resources/github/'],
            ['label' => 'Writing Templates', 'path' => '/resources/templates/'],
        ],
    ],
    ['label' => 'Join Us', 'path' => '/join/'],
    ['label' => 'Contact', 'path' => '/contact/'],
];
