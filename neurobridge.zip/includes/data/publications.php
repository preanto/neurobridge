<?php
/**
 * Publications — journal articles and peer-reviewed conference papers.
 * ---------------------------------------------------------------------------
 * SAMPLE CONTENT. Titles, venues, DOIs and indexing badges are placeholders.
 * Replace with the group's verified publication record; DOI links must resolve.
 *
 * Field reference
 *   authors  : string  — lab members should be wrapped as **Name** for bold
 *   year     : int
 *   venue    : string  — journal or conference name
 *   detail   : string  — volume/issue/pages, or proceedings information
 *   indexes  : array   — badge labels used by the filters (Scopus, Q1, SCIE, …)
 *   doi      : string  — bare DOI, e.g. 10.1000/xyz123  (empty string if none)
 *   url      : string  — optional direct link (overrides the DOI link)
 *   domains  : array   — research domains used by the topic filter
 *   open     : bool    — open access
 */

declare(strict_types=1);

return [

    // =====================================================================
    // Journal articles
    // =====================================================================
    'journal' => [
        [
            'title'   => 'Neuroimmunology of Oral Cancer: Tumor Progression, Systemic Inflammation, and Neural Circuit Dysfunction from the Cerebellum to the Frontal Cortex',
            'authors' => 'Iftakhar Ahmad, Masudur Rahman Kanchon, Tasmia Jahin Mim, Md Foyzur Rahman, Tahsin Khaled Bashar, Sunzida Rahman Medha, Sabrina Monsur, Sheik Tasnim Akter',
            'year'    => 2026,
            'venue'   => ' Molecular Biology Reports',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q2', 'PubMed'],
            'doi'     => '10.1007/s11033-026-12644-7',
            'domains' => ['Neuroimmunology', 'Neuroinflammation', 'Oral cancer'],
            'open'    => True,
        ],
        [
            'title'   => 'Magnetically actuated microrobots in urolithiasis: emerging frontiers in kidney stone diagnosis and management',
            'authors' => 'Iftakhar Ahmad, Tasmia Jahin Mim, Purnata Ghosh, Maryum Tahir, Ali Emami, Nimrah Seher, Fouzia Tasnim, Sachin Kothawade, Vijaya Padwal, Bhushan Rane',
            'year'    => 2026,
            'venue'   => 'Inflammopharmacology',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q1', 'PubMed'],
            'doi'     => '10.1007/s10787-026-02382-4',
            'domains' => ['Urolithiasis', 'Magnetic microrobots', 'Stone fragmentation', 'Image-guided navigation'],
            'open'    => False,
        ],
        [
            'title'   => 'Wearable neural biosensors for early detection of neurodegenerative diseases',
            'authors' => 'Iftakhar Ahmad, Kumbha Ravindra, Yemineni Bala Bhargavi, Kojja Lakshmi Nagaraju, Jasvitha Mandava, Tasmia Jahin Mim, Sakshi Arun Dongare',
            'year'    => 2026,
            'venue'   => 'Discover Neuroscience',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q2', 'PubMed', 'Open Access'],
            'doi'     => '10.1186/s13064-026-00302-4',
            'domains' => ['Wearable neural biosensor', 'Parkinson\'s disease', 'Nanomaterials'],
            'open'    => true,
        ],
        [
            'title'   => 'Bioactive compounds for neuroinflammation and neuropathic pain management: molecular and cellular mechanisms',
            'authors' => 'Iftakhar Ahmad, Sachin Kothawade, Tasmia Jahin Mim, Diksha Jindal, Progga Paromita, Ayesha Khan, Ruhul Amin, Md Omar Faruk, Sabuj Sutradhar, Bhushan Rane',
            'year'    => 2026,
            'venue'   => 'Inflammopharmacology',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q1', 'PubMed'],
            'doi'     => '10.1007/s10787-026-02278-3',
            'domains' => ['Neuroinflammation', 'Bioactive compounds', 'Microglial polarization', 'Neuropathic pain'],
            'open'    => false,
        ],
        [
            'title'   => 'Klebsiella pneumoniae and urinary tract infections: pathogenesis, resistance, and advances in management',
            'authors' => 'Tasmia Jahin Mim, Iftakhar Ahmad, Victoria Lee Hrach, Kingsley Kwaku Amoateng, Md Piar Rahaman Shihab, Hafsa Abdulhamid Abdulsalam, Dinesh Kumar, Neeraj Choudhary, Suresh Babu Kondaveeti',
            'year'    => 2026,
            'venue'   => 'European Journal of Medical Research',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q1', 'PubMed', 'Open Access'],
            'doi'     => '10.1186/s40001-026-04589-1',
            'domains' => ['Urinary tract infections', 'Multidrug resistance', 'Urinary microbiome'],
            'open'    => true,
        ],
        [
            'title'   => 'Novel Cellular Signalling Axes in Neurodegenerative Diseases: From NLRP3 Inflammasome to Wnt/β‐Catenin and Hippo‐YAP Pathways',
            'authors' => 'Kuldeep Singh, Iftakhar Ahmad, Divya Jain, Tasmia Jahin Mim, Abdullah Al Noman, Md Piar Rahaman Shihab, Suresh Babu Kondaveeti, Jeetendra Kumar Gupta, Pranay Wal',
            'year'    => 2026,
            'venue'   => 'Journal of Biochemical and Molecular Toxicology',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q2', 'PubMed'],
            'doi'     => '10.1002/jbt.70880',
            'domains' => ['Neurodegenerative Diseases'],
            'open'    => false,
        ],
        [
            'title'   => 'Coconut Husk for Second-generation Biofuel Production to Advance a Circular Economy',
            'authors' => 'Tasmia Jahin Mim, Iftakhar Ahmad, Abdullah Al Noman, Divya Jain, Kuldeep Singh',
            'year'    => 2026,
            'venue'   => 'Current Green Chemistry',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q3', 'PubMed'],
            'doi'     => '10.2174/0122133461376861250625225817',
            'domains' => ['Biofuel Production'],
            'open'    => false,
        ],
        [
            'title'   => 'Plants as Medicine for Autism: Reviewing the Evidence for Phytopharmaceuticals for ASD',
            'authors' => 'Abdullah Al Noman, Sanzida Alam Flora, Susmita Deb Tonni, Cinmoy Barua, Anik Kumar Nath, Kaniz Fatema Bristy, Iftakhar Ahmad, Rashmi Pathak, Himanshu Sharma',
            'year'    => 2026,
            'venue'   => 'Current Bioactive Compounds',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q3', 'PubMed'],
            'doi'     => '10.2174/0115734072347775250129042526',
            'domains' => ['ASD', 'Autism'],
            'open'    => false,
        ],
        [
            'title'   => 'Stem cells in organogenesis and regeneration',
            'authors' => 'Tasmia Jahin Mim, Iftakhar Ahmad, Salima Raiyan Basher, Md Foyzur Rahman, Sandeep Reddy Ambati, Kiranmai Venkatagiri, Nimrah Seher, Dinesh Kumar, Neeraj Choudhary, Suresh Babu Kondaveeti',
            'year'    => 2026,
            'venue'   => 'Stem Cell Research & Therapy',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q1', 'PubMed', 'Open Access'],
            'doi'     => '10.1186/s13287-025-04889-z',
            'domains' => ['Synthetic biology', 'Stem cells'],
            'open'    => true,
        ],
        [
            'title'   => 'Bridging mind and gut: The molecular mechanisms of microRNA, microbiota, and cytokine interactions in depression',
            'authors' => 'Himanshu Sharma, Abdullah Al Noman, Iftakhar Ahmad, Susmita Deb Tonni, Tasmia Jahin Mim, Fahmida Afrose, Pranab Dev Sharma, Anwar Parvez, Samanta Tamanna, Md Al Azad, Rashmi Pathak',
            'year'    => 2026,
            'venue'   => 'Current Gene Therapy',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q2', 'PubMed'],
            'doi'     => '10.2174/0115665232361169250617192348',
            'domains' => ['microRNA'],
            'open'    => false,
        ],
        [
            'title'   => 'Curcumin and neuroinflammation in autism: Mechanistic insights and therapeutic implications',
            'authors' => 'Abdullah Al Noman, Susmita Deb Tonni, Md Al Mamun, Iftakhar Ahmad, Monty Datta, Pranab Dev Sharma, Kaniz Fatama Khan, Md Jahed Rana, Himanshu Sharma, Vetriselvan Subramaniyan',
            'year'    => 2025,
            'venue'   => 'Adv Neurol',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q4'],
            'doi'     => '10.36922/AN025350089',
            'domains' => ['neuroinflammation'],
            'open'    => true,
        ],
        [
            'title'   => 'A review of plant-derived gums and mucilages: Structural chemistry, film forming properties and application',
            'authors' => 'Md Azizul Hakim Shiam, Mst Sadia Islam, Iftakhar Ahmad, Sumaiya Sadia Haque',
            'year'    => 2025,
            'venue'   => 'Journal of Plastic Film & Sheeting',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q3'],
            'doi'     => '10.1177/87560879251316553',
            'domains' => ['Structural chemistry'],
            'open'    => false,
        ],
        [
            'title'   => 'Nicotine exposure in pregnancy and its link to autism spectrum disorder: a review on evidence, biological pathways, and directions for future research in neurological disorders',
            'authors' => 'Iftakhar Ahmad, Abdullah Al Noman, Monty Datta, Md Maruf Parves, Rashmi Pathak, Himanshu Sharma',
            'year'    => 2025,
            'venue'   => 'Current Psychiatry Research and Reviews',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q4'],
            'doi'     => '10.2174/0126660822328919241212114244',
            'domains' => ['Neurological Disorders'],
            'open'    => false,
        ],
          [
            'title'   => 'Plant development and heat stress: role of exogenous nutrients and phytohormones in thermotolerance',
            'authors' => 'Prodipto Bishnu Angon, Arpan Das, Arpita Rani Roy, Jamia Jahan Khan, Iftakhar Ahmad, Ashish Biswas, Abu Talha Pallob, Monisha Mondol, Syeda Tahmida Yeasmin',
            'year'    => 2024,
            'venue'   => 'Discover Plants',
            'detail'  => '',
            'indexes' => ['Scopus', 'SCIE', 'Q1'],
            'doi'     => '10.1007/s44372-024-00020-3',
            'domains' => ['Plant nutrients','Phytohormones'],
            'open'    => true,
        ],
    ],

    // =====================================================================
    // Conference papers & proceedings
    // =====================================================================
    'conference' => [
        // [
        //     'title'   => 'Attention-based fusion of EEG and clinical features for early detection of cognitive decline',
        //     'authors' => 'Joy SM, Fahim MH, Chowdhury I, **Siddique TH**',
        //     'year'    => 2026,
        //     'venue'   => 'IEEE International Conference on Biomedical Engineering and Informatics (BMEI 2026)',
        //     'detail'  => 'Proceedings, pp. 214–221',
        //     'location'=> 'Kuala Lumpur, Malaysia',
        //     'date'    => '12–14 March 2026',
        //     'indexes' => ['IEEE Xplore', 'Scopus'],
        //     'doi'     => '10.1109/BMEI.2026.0000214',
        //     'domains' => ['Neuroscience', 'Bioinformatics'],
        //     'type'    => 'Full paper',
        // ],

    ],
];
