<?php
/**
 * Organisation identity, mission text, impact metrics and testimonials.
 * ---------------------------------------------------------------------------
 * NOTE: Names, figures and quotations below are realistic SAMPLE CONTENT for
 * the template. Replace them with verified information before going live.
 */

declare(strict_types=1);

return [
    'name'      => 'Neurobridge Research',
    'short'     => 'Neurobridge',
    'tagline'   => 'Bridging disciplines. Building researchers.',
    'founded'   => 2021,
    'meta_description' => 'Neurobridge Research is a Bangladesh-based bioscience research and training organisation working across neuroscience, bioinformatics, biotechnology, molecular biology, microbiology, pharmacology and chemistry.',

    'intro' => 'Neurobridge Research is a Bangladesh-based bioscience research and training organisation dedicated to empowering students, emerging researchers, and educators through interdisciplinary scientific discovery.',

    'about' => [
        'Neurobridge Research is a Bangladesh-based bioscience research and training organisation dedicated to empowering students, emerging researchers, and educators through interdisciplinary scientific discovery. By integrating expertise across seven core disciplines — Neuroscience, Bioinformatics, Biotechnology, Molecular Biology, Microbiology, Pharmacology, and Chemistry — Neurobridge fosters collaborative research to uncover novel therapeutic targets, develop advanced technologies, and address complex challenges in health and life sciences.',
        'Committed to education, inclusivity, and innovation, the organisation bridges knowledge across disciplines to translate cutting-edge scientific findings into practical, impactful solutions for healthcare and society. Our teams pair computational discovery with wet-lab validation, and every project is structured so that an undergraduate can enter as a trainee and leave as a published, independent investigator.',
    ],

    'mission' => '•	Promote neuroscience and neurological research in Bangladesh.
•	Support students and early-career researchers.
•	Build national and international research collaborations.
•	Provide research education and training.
•	Increase scientific publication output from Bangladesh.
•	Translate neuroscience knowledge into public health impact.
',

    'vision' => 'To become a leading neuroscience research and education network in South Asia, empowering students, clinicians, and researchers through innovation, collaboration, mentorship, and scientific excellence.',

    'values' => [
        ['title' => 'Rigour before speed', 'text' => 'Pre-registered analysis plans, reproducible pipelines, and honest reporting of negative results.'],
        ['title' => 'Open by default',      'text' => 'Datasets, code, and protocols are released with every publication unless ethics restrict them.'],
        ['title' => 'Inclusive access',     'text' => 'No application fee, no tuition, and remote participation for students outside Dhaka.'],
        ['title' => 'Mentorship as method', 'text' => 'Every trainee works inside a tiered team — fellow, associate, and principal investigator.'],
    ],

    'what_we_do' => [
        [
            'title' => 'Interdisciplinary research',
            'text'  => 'We run project teams that combine computational screening, molecular work, and clinical data analysis around a single translational question.',
            'icon'  => 'flask',
        ],
        [
            'title' => 'Structured training',
            'text'  => 'Cohort-based programmes in research methodology, bioinformatics, scientific writing, and reproducible analysis — delivered in Bangla and English.',
            'icon'  => 'book',
        ],
        [
            'title' => 'Publication mentorship',
            'text'  => 'Manuscript clinics, internal peer review, and co-authorship pathways that take trainees from a first draft to an indexed journal.',
            'icon'  => 'document',
        ],
        [
            'title' => 'Higher-study guidance',
            'text'  => 'Statement-of-purpose review, supervisor outreach strategy, and funding search support for students applying abroad.',
            'icon'  => 'globe',
        ],
        [
            'title' => 'Open science resources',
            'text'  => 'Curated datasets, reusable analysis repositories, and manuscript templates released for the wider community.',
            'icon'  => 'database',
        ],
        [
            'title' => 'Institutional partnerships',
            'text'  => 'MoUs with universities, hospitals and laboratories that give our teams access to instrumentation and clinical cohorts.',
            'icon'  => 'handshake',
        ],
    ],

    'metrics' => [
        ['value' => 96,  'suffix' => '+', 'label' => 'Members & trainees',   'note' => 'Across research, fellowship and training tracks'],
        ['value' => 74,  'suffix' => '',  'label' => 'Published articles',   'note' => 'Journal and peer-reviewed conference papers'],
        ['value' => 12,  'suffix' => '',  'label' => 'Funded grants',        'note' => 'Institutional, national and seed research grants'],
        ['value' => 19,  'suffix' => '',  'label' => 'Partner institutions', 'note' => 'MoUs and active collaboration agreements'],
        ['value' => 31,  'suffix' => '',  'label' => 'Funded admits',        'note' => 'Members placed in funded graduate programmes'],
        ['value' => 7,   'suffix' => '',  'label' => 'Core disciplines',     'note' => 'Working together inside every project team'],
    ],

    'testimonials' => [
        [
            'quote'  => 'Neurobridge gave me the first structured research experience of my life. I joined knowing how to read a paper and left knowing how to design a study, run the analysis, and defend it in review.',
            'name'   => 'Nusrat Jahan Anika',
            'role'   => 'Alumna, 2023 cohort — now PhD student, University of Groningen',
        ],
        [
            'quote'  => 'What distinguishes this group is the insistence on reproducibility. Every collaborative manuscript arrived with the code, the data dictionary, and a clean analysis log attached.',
            'name'   => 'Prof. Dr. Marianne Osei',
            'role'   => 'Advisory Committee — Department of Pharmacology, University of Ghana',
        ],
        [
            'quote'  => 'The training programme reaches students in district universities who would otherwise never touch a molecular docking pipeline or a sequencing dataset. That reach is the real achievement.',
            'name'   => 'Dr. Shafiul Alam Chowdhury',
            'role'   => 'Steering Committee — Public health researcher, Dhaka',
        ],
        [
            'quote'  => 'We signed an MoU expecting a student exchange. What we received was a genuine research partnership with rigorous, well-documented contributions on both sides.',
            'name'   => 'Assoc. Prof. Kenji Watanabe',
            'role'   => 'International Collaborator — Graduate School of Biomedical Sciences, Nagasaki',
        ],
    ],

    'contact' => [
        'email'     => 'neurobridgeresearchbangladesh@gmail.com',
        'admissions'=> 'neurobridgeresearchbangladesh@gmail.com',
        'press'     => 'neurobridgeresearchbangladesh@gmail.com',
        'phone'     => '',
        'address'   => [
            'line1'   => 'Neurobridge Research',
            'line2'   => '',
            'city'    => 'Dhaka',
            'country' => 'Bangladesh',
        ],
        'hours'     => 'Sunday – Thursday, 10:00 – 18:00 (GMT+6)',
        'map_query' => 'Banani, Dhaka, Bangladesh',
    ],

    'social' => [
        ['label' => 'LinkedIn',        'url' => 'https://www.linkedin.com/company/neurobridge-research-bangladesh/'],
        ['label' => 'Google Scholar',  'url' => 'https://scholar.google.com/'],
        ['label' => 'GitHub',          'url' => 'https://github.com/neurobridge-research'],
        ['label' => 'ResearchGate',    'url' => 'https://www.researchgate.net/'],
        ['label' => 'Facebook',        'url' => 'https://www.facebook.com/'],
    ],
];
