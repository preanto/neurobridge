<?php
/**
 * Latest news — used by the home page ticker and the news list.
 * SAMPLE CONTENT.
 */

declare(strict_types=1);

return [
    [
        'date'     => '2026-08-11',
        'date_text'=> '11 August 2026',
        'tag'      => 'Publication',
        'title'    => 'Multi-target screening study accepted in Journal of Biomolecular Structure and Dynamics',
        'text'     => 'The neurodegeneration team\'s integrated docking, ADMET and molecular dynamics study of Bangladeshi ethnomedicinal phytochemicals has been accepted for publication.',
        'url'      => '/publications/journal/',
    ],
    [
        'date'     => '2026-07-28',
        'date_text'=> '28 July 2026',
        'tag'      => 'Admissions',
        'title'    => 'Applications open for the 2026–27 Research Fellowship cohort',
        'text'     => 'Twelve fellowship places are open across all seven disciplines. Applications close on 30 September 2026; there is no application fee.',
        'url'      => '/join/',
    ],
    [
        'date'     => '2026-07-02',
        'date_text'=> '2 July 2026',
        'tag'      => 'Wall of Scholars',
        'title'    => 'Four members receive fully funded PhD and MS offers for the 2026 intake',
        'text'     => 'Offers from KU Leuven, the University of Queensland, the University of Alberta and the University of Tartu bring the total number of funded placements to 31.',
        'url'      => '/team/scholars/',
    ],
    [
        'date'     => '2026-05-21',
        'date_text'=> '21 May 2026',
        'tag'      => 'MoU',
        'title'    => 'Partnership agreement signed with Nagasaki University',
        'text'     => 'A three-year memorandum covering student exchange, fellow co-supervision and joint publication in antimicrobial resistance genomics.',
        'url'      => '/events/',
    ],
    [
        'date'     => '2026-04-09',
        'date_text'=> '9 April 2026',
        'tag'      => 'Open data',
        'title'    => 'Type 2 diabetes microbiome cohort released on NCBI SRA',
        'text'     => 'Sequences and de-identified clinical metadata for 312 participants are now publicly available, together with the full analysis repository.',
        'url'      => '/resources/datasets/',
    ],
    [
        'date'     => '2026-03-15',
        'date_text'=> '15 March 2026',
        'tag'      => 'Event',
        'title'    => 'National Symposium on Interdisciplinary Bioscience closes with 310 participants',
        'text'     => 'Two days, 41 oral presentations and 68 posters from 24 institutions across Bangladesh.',
        'url'      => '/events/',
    ],
    [
        'date'     => '2026-02-20',
        'date_text'=> '20 February 2026',
        'tag'      => 'Grant',
        'title'    => 'Seed grant awarded for point-of-care diagnostic prototyping',
        'text'     => 'A twelve-month award will fund the biosensor strip prototype and its field validation with two district hospitals.',
        'url'      => '/research/',
    ],
    [
        'date'     => '2026-01-19',
        'date_text'=> '19 January 2026',
        'tag'      => 'Training',
        'title'    => 'Docking & dynamics workshop trains 46 participants from 11 universities',
        'text'     => 'The three-day hands-on programme is now scheduled twice a year, with fee waivers for students outside Dhaka.',
        'url'      => '/events/',
    ],
];
