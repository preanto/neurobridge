<?php
/**
 * Research resources: datasets, code repositories and writing templates.
 * SAMPLE CONTENT — replace links, DOIs and citation strings with real records.
 */

declare(strict_types=1);

return [

    // =====================================================================
    // Datasets
    // =====================================================================
    'datasets' => [
        [
            'title'    => 'Bangladeshi Type 2 Diabetes Gut Microbiome Cohort (16S rRNA)',
            'repo'     => 'NCBI SRA',
            'accession'=> 'PRJNA0000001',
            'year'     => 2026,
            'size'     => '312 samples · 18.4 GB',
            'licence'  => 'Open (NCBI terms)',
            'domains'  => ['Microbiology', 'Molecular Biology'],
            'summary'  => 'Paired 16S rRNA amplicon sequences and de-identified clinical metadata (HbA1c, BMI, medication) from 312 adults recruited across three Dhaka clinics.',
            'url'      => 'https://www.ncbi.nlm.nih.gov/bioproject/',
            'citation' => 'Ridhi SA, Nishat TA, Brandt M, Yeasmin F. Bangladeshi Type 2 Diabetes Gut Microbiome Cohort. NCBI BioProject PRJNA0000001; 2026.',
        ],
        [
            'title'    => 'Ethnomedicinal Phytochemical Library of Bangladesh (v2)',
            'repo'     => 'Mendeley Data',
            'accession'=> '10.17632/nbrg2v2.1',
            'year'     => 2025,
            'size'     => '1,842 compounds · 6 MB',
            'licence'  => 'CC BY 4.0',
            'domains'  => ['Chemistry', 'Pharmacology', 'Bioinformatics'],
            'summary'  => 'Curated 3D structures, SMILES, source species and literature provenance for 1,842 phytochemicals reported from Bangladeshi medicinal plants — ready for virtual screening.',
            'url'      => 'https://data.mendeley.com/',
            'citation' => 'Mim FH, Rony MA, Siddique TH. Ethnomedicinal Phytochemical Library of Bangladesh, v2. Mendeley Data; 2025. doi:10.17632/nbrg2v2.1',
        ],
        [
            'title'    => 'Clinical Laboratory Panel for Sepsis Risk Modelling (de-identified)',
            'repo'     => 'Zenodo',
            'accession'=> '10.5281/zenodo.0000002',
            'year'     => 2026,
            'size'     => '4,110 admissions · 28 MB',
            'licence'  => 'CC BY-NC 4.0',
            'domains'  => ['Bioinformatics'],
            'summary'  => 'De-identified routine laboratory time-series for 4,110 ICU admissions with outcome labels, released with the data dictionary and the exact train/test split used in the paper.',
            'url'      => 'https://zenodo.org/',
            'citation' => 'Joy SM, Ramanathan P, Siddique TH. Clinical Laboratory Panel for Sepsis Risk Modelling. Zenodo; 2026. doi:10.5281/zenodo.0000002',
        ],
        [
            'title'    => 'Resting-State EEG Recordings in Mild Cognitive Impairment',
            'repo'     => 'PhysioNet',
            'accession'=> 'neurobridge-eeg-mci/1.0.0',
            'year'     => 2025,
            'size'     => '96 participants · 42 GB',
            'licence'  => 'PhysioNet Restricted Health Data',
            'domains'  => ['Neuroscience', 'Bioinformatics'],
            'summary'  => 'Nineteen-channel resting-state recordings with MoCA scores and demographic covariates, collected under the Institute of Neurosciences MoU with participant consent for research reuse.',
            'url'      => 'https://physionet.org/',
            'citation' => 'Tabassum R, Joy SM, Siddique TH. Resting-State EEG Recordings in Mild Cognitive Impairment (v1.0.0). PhysioNet; 2025.',
        ],
        [
            'title'    => 'Carbapenem-Resistant Klebsiella pneumoniae Genome Collection (Dhaka)',
            'repo'     => 'NCBI GenBank',
            'accession'=> 'PRJNA0000003',
            'year'     => 2025,
            'size'     => '84 assemblies · 460 MB',
            'licence'  => 'Open (NCBI terms)',
            'domains'  => ['Microbiology', 'Bioinformatics'],
            'summary'  => 'Draft assemblies and resistance-gene annotations for 84 clinical isolates collected from four tertiary hospitals, with antibiogram metadata.',
            'url'      => 'https://www.ncbi.nlm.nih.gov/genbank/',
            'citation' => 'Nishat TA, Karim A, Yeasmin F. Carbapenem-Resistant K. pneumoniae Genome Collection, Dhaka. NCBI BioProject PRJNA0000003; 2025.',
        ],
        [
            'title'    => 'Green-Synthesised Nanoparticle Characterisation Records',
            'repo'     => 'Mendeley Data',
            'accession'=> '10.17632/nbrg-agnp.1',
            'year'     => 2025,
            'size'     => '38 syntheses · 220 MB',
            'licence'  => 'CC BY 4.0',
            'domains'  => ['Biotechnology', 'Chemistry'],
            'summary'  => 'UV-Vis, FTIR, XRD and SEM records for 38 plant-extract-mediated silver nanoparticle syntheses with the corresponding zone-of-inhibition results.',
            'url'      => 'https://data.mendeley.com/',
            'citation' => 'Sultana N, Ferdous T, Islam MR. Green-Synthesised Nanoparticle Characterisation Records. Mendeley Data; 2025. doi:10.17632/nbrg-agnp.1',
        ],
    ],

    // =====================================================================
    // Code repositories
    // =====================================================================
    'repositories' => [
        [
            'name'     => 'nbrg-rnaseq-workflow',
            'title'    => 'Reproducible RNA-seq workflow',
            'language' => 'Nextflow / R',
            'licence'  => 'MIT',
            'stars'    => 214,
            'updated'  => 'June 2026',
            'domains'  => ['Bioinformatics', 'Molecular Biology'],
            'summary'  => 'End-to-end differential expression pipeline benchmarked for low-input clinical samples: QC, alignment, quantification, DE testing and a self-contained HTML report.',
            'url'      => 'https://github.com/neurobridge-research/nbrg-rnaseq-workflow',
        ],
        [
            'name'     => 'dockflow',
            'title'    => 'Batch docking & MD preparation toolkit',
            'language' => 'Python',
            'licence'  => 'MIT',
            'stars'    => 168,
            'updated'  => 'May 2026',
            'domains'  => ['Bioinformatics', 'Chemistry'],
            'summary'  => 'Prepares ligand libraries, runs batch AutoDock Vina jobs, ranks poses, and emits GROMACS-ready inputs for the top hits — with a resumable job queue.',
            'url'      => 'https://github.com/neurobridge-research/dockflow',
        ],
        [
            'name'     => 'resistome-lite',
            'title'    => 'Lightweight resistome annotation pipeline',
            'language' => 'Python / Snakemake',
            'licence'  => 'GPL-3.0',
            'stars'    => 96,
            'updated'  => 'February 2026',
            'domains'  => ['Microbiology', 'Bioinformatics'],
            'summary'  => 'Assembly-to-report AMR gene calling designed to run on a single 16 GB workstation, with CARD/ResFinder harmonisation and a plain-language summary sheet.',
            'url'      => 'https://github.com/neurobridge-research/resistome-lite',
        ],
        [
            'name'     => 'clinrisk',
            'title'    => 'Calibrated clinical risk modelling toolkit',
            'language' => 'Python',
            'licence'  => 'Apache-2.0',
            'stars'    => 131,
            'updated'  => 'April 2026',
            'domains'  => ['Bioinformatics'],
            'summary'  => 'Training and evaluation utilities that enforce calibration reporting, decision-curve analysis and external validation before a model is considered finished.',
            'url'      => 'https://github.com/neurobridge-research/clinrisk',
        ],
        [
            'name'     => 'eeg-features',
            'title'    => 'EEG feature extraction for cognitive studies',
            'language' => 'Python / MNE',
            'licence'  => 'BSD-3-Clause',
            'stars'    => 74,
            'updated'  => 'January 2026',
            'domains'  => ['Neuroscience', 'Bioinformatics'],
            'summary'  => 'Preprocessing, artefact rejection and spectral/connectivity feature extraction, packaged so a trainee can reproduce the published feature table in one command.',
            'url'      => 'https://github.com/neurobridge-research/eeg-features',
        ],
        [
            'name'     => 'nbrg-figures',
            'title'    => 'Publication figure toolkit',
            'language' => 'R',
            'licence'  => 'MIT',
            'stars'    => 58,
            'updated'  => 'March 2026',
            'domains'  => ['Bioinformatics', 'Chemistry'],
            'summary'  => 'A ggplot2 theme, colour-blind-safe palettes and export helpers that produce journal-compliant figures at the correct dimensions and DPI.',
            'url'      => 'https://github.com/neurobridge-research/nbrg-figures',
        ],
    ],

    // =====================================================================
    // Writing templates & guidelines
    // =====================================================================
    'templates' => [
        [
            'title'   => 'Neurobridge Manuscript Template (LaTeX)',
            'format'  => 'LaTeX',
            'version' => 'v3.2 · July 2026',
            'summary' => 'IMRaD manuscript class with a preconfigured bibliography style, a structured abstract environment, and a reporting-checklist appendix.',
            'includes'=> ['main.tex', 'references.bib', 'nbrg.cls', 'reporting-checklist.tex'],
            'url'     => '#',
            'overleaf'=> 'https://www.overleaf.com/',
        ],
        [
            'title'   => 'Neurobridge Manuscript Template (Word)',
            'format'  => 'Word',
            'version' => 'v3.2 · July 2026',
            'summary' => 'The same structure as the LaTeX class in .docx form, with styles already mapped to heading levels, figure captions and table captions.',
            'includes'=> ['manuscript-template.docx', 'style-guide.pdf'],
            'url'     => '#',
            'overleaf'=> '',
        ],
        [
            'title'   => 'Undergraduate Thesis Template',
            'format'  => 'LaTeX + Word',
            'version' => 'v2.0 · January 2026',
            'summary' => 'Front matter, declaration and acknowledgement pages, chapter structure and a bibliography set-up that satisfies most Bangladeshi university formatting rules.',
            'includes'=> ['thesis.tex', 'thesis-template.docx', 'formatting-notes.md'],
            'url'     => '#',
            'overleaf'=> 'https://www.overleaf.com/',
        ],
        [
            'title'   => 'Conference Poster Template (A0)',
            'format'  => 'LaTeX (beamerposter) + PowerPoint',
            'version' => 'v1.4 · November 2025',
            'summary' => 'A0 portrait layout with a fixed three-column grid, the group\'s colour-blind-safe palette, and guidance on font sizes that stay legible at two metres.',
            'includes'=> ['poster.tex', 'poster-template.pptx'],
            'url'     => '#',
            'overleaf'=> 'https://www.overleaf.com/',
        ],
        [
            'title'   => 'Research Protocol & Ethics Submission Pack',
            'format'  => 'Word',
            'version' => 'v2.1 · March 2026',
            'summary' => 'Protocol skeleton, participant information sheet, consent form and data management plan — the documents an ethical review board will ask for.',
            'includes'=> ['protocol.docx', 'participant-information.docx', 'consent-form.docx', 'data-management-plan.docx'],
            'url'     => '#',
            'overleaf'=> '',
        ],
        [
            'title'   => 'Reference & Citation Style Guide',
            'format'  => 'PDF',
            'version' => 'v1.8 · February 2026',
            'summary' => 'How the group cites datasets, software and preprints, plus ready-to-import Zotero and Mendeley style files for Vancouver and APA 7.',
            'includes'=> ['citation-guide.pdf', 'nbrg-vancouver.csl', 'nbrg-apa7.csl'],
            'url'     => '#',
            'overleaf'=> '',
        ],
    ],

    'guidelines' => [
        ['title' => 'Authorship policy',       'text' => 'Authorship requires substantive contribution to design, execution or analysis, plus approval of the final manuscript. Order is agreed in writing before the first draft.'],
        ['title' => 'Data availability',       'text' => 'Every paper is submitted with a data availability statement pointing to a public deposit, or a documented reason why deposit is not possible.'],
        ['title' => 'Code release',            'text' => 'Analysis code is tagged at the version used for the submitted results and archived with a DOI at acceptance.'],
        ['title' => 'Internal review',         'text' => 'No manuscript leaves the group without two internal reviews — one methodological, one from outside the project team.'],
        ['title' => 'Predatory venue screening','text' => 'Target journals are checked against index listings and publisher records before submission; the group does not publish in unindexed pay-to-publish venues.'],
    ],
];
