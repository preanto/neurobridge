<?php
/**
 * Inline SVG icon set (stroke-based, 24x24 viewBox).
 * Usage: echo icon('brain');
 */

declare(strict_types=1);

function icon(string $name, string $class = ''): string
{
    $paths = [
        'brain'     => '<path d="M9.5 3.5A2.5 2.5 0 0 0 7 6v.2A2.8 2.8 0 0 0 5 9a2.8 2.8 0 0 0 .9 2A2.8 2.8 0 0 0 5 13c0 1.1.6 2 1.5 2.5A2.5 2.5 0 0 0 9 19a2.5 2.5 0 0 0 3-2.4V6a2.5 2.5 0 0 0-2.5-2.5Z"/><path d="M14.5 3.5A2.5 2.5 0 0 1 17 6v.2A2.8 2.8 0 0 1 19 9a2.8 2.8 0 0 1-.9 2A2.8 2.8 0 0 1 19 13c0 1.1-.6 2-1.5 2.5A2.5 2.5 0 0 1 15 19a2.5 2.5 0 0 1-3-2.4"/>',
        'code'      => '<path d="m8 16-4-4 4-4"/><path d="m16 8 4 4-4 4"/><path d="m13.5 5-3 14"/>',
        'dna'       => '<path d="M4 3c0 6 16 6 16 12M4 21c0-6 16-6 16-12"/><path d="M6.5 6h11M6.5 18h11M9 3.5h6M9 20.5h6"/>',
        'helix'     => '<path d="M7 3v3c0 3 10 3 10 6s-10 3-10 6v3"/><path d="M17 3v3c0 3-10 3-10 6s10 3 10 6v3"/>',
        'microbe'   => '<circle cx="12" cy="12" r="6"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M19 5l-1.5 1.5M6.5 17.5 5 19"/><circle cx="10" cy="10.5" r="1"/><circle cx="14" cy="13.5" r="1"/>',
        'pill'      => '<rect x="2.5" y="8.5" width="19" height="7" rx="3.5" transform="rotate(-45 12 12)"/><path d="M9 9l6 6"/>',
        'atom'      => '<circle cx="12" cy="12" r="2"/><ellipse cx="12" cy="12" rx="10" ry="4.2"/><ellipse cx="12" cy="12" rx="10" ry="4.2" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="10" ry="4.2" transform="rotate(120 12 12)"/>',
        'flask'     => '<path d="M9.5 3h5M10.5 3v6L5 18.5A2 2 0 0 0 6.7 21.5h10.6A2 2 0 0 0 19 18.5L13.5 9V3"/><path d="M7.8 14.5h8.4"/>',
        'book'      => '<path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H19v18H5.5A1.5 1.5 0 0 1 4 19.5Z"/><path d="M4 17h15"/><path d="M8 7h7"/>',
        'document'  => '<path d="M14 3H7a1.5 1.5 0 0 0-1.5 1.5v15A1.5 1.5 0 0 0 7 21h10a1.5 1.5 0 0 0 1.5-1.5V7.5Z"/><path d="M14 3v4.5h4.5"/><path d="M9 12.5h6M9 16h6"/>',
        'globe'     => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18Z"/>',
        'database'  => '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
        'handshake' => '<path d="m11 17 2 2a1.5 1.5 0 0 0 2.1-2.1"/><path d="M13.1 16.9 15 18.8a1.5 1.5 0 0 0 2.1-2.1l-4.6-4.6"/><path d="M3 8.5 7 5h3l3.5 3.5"/><path d="M21 8.5 17 5h-2.5"/><path d="M3 8.5v6l4 3.5a1.5 1.5 0 0 0 2.2-2"/><path d="M21 8.5v6"/>',
        'mail'      => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6 8.5-6"/>',
        'phone'     => '<path d="M6.5 3h3l1.5 4-2 1.5a11 11 0 0 0 5 5L15.5 12l4 1.5v3a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 3 6.2 2 2 0 0 1 5 4Z"/>',
        'pin'       => '<path d="M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
        'clock'     => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
        'calendar'  => '<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
        'users'     => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 5.2a3.5 3.5 0 0 1 0 5.6M17.5 14.5a6.5 6.5 0 0 1 4 6"/>',
        'search'    => '<circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 4 4"/>',
        'external'  => '<path d="M14 4h6v6"/><path d="M20 4 11 13"/><path d="M18 14v5.5A1.5 1.5 0 0 1 16.5 21h-12A1.5 1.5 0 0 1 3 19.5v-12A1.5 1.5 0 0 1 4.5 6H10"/>',
        'download'  => '<path d="M12 3v12"/><path d="m7.5 11 4.5 4.5 4.5-4.5"/><path d="M4 20h16"/>',
        'check'     => '<path d="m4.5 12.5 5 5 10-11"/>',
        'award'     => '<circle cx="12" cy="9" r="5.5"/><path d="m8.5 13.5-1.5 7 5-2.5 5 2.5-1.5-7"/>',
        'chart'     => '<path d="M4 20h16"/><path d="M7 20V11M12 20V5M17 20v-6"/>',
        'target'    => '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
        'quote'     => '<path d="M9 6c-3 1.5-4.5 4-4.5 7.5V18H10v-5.5H7.2c0-2 .8-3.4 2.6-4.3ZM19.5 6c-3 1.5-4.5 4-4.5 7.5V18h5.5v-5.5h-2.8c0-2 .8-3.4 2.6-4.3Z"/>',
    ];

    $body  = $paths[$name] ?? $paths['target'];
    $class = $class !== '' ? ' class="' . htmlspecialchars($class, ENT_QUOTES) . '"' : '';

    return '<svg' . $class . ' viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" '
        . 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $body . '</svg>';
}

/** Icon used for each research domain. */
function domain_icon(string $domain): string
{
    $map = [
        'Neuroscience'      => 'brain',
        'Bioinformatics'    => 'code',
        'Biotechnology'     => 'dna',
        'Molecular Biology' => 'helix',
        'Microbiology'      => 'microbe',
        'Pharmacology'      => 'pill',
        'Chemistry'         => 'atom',
    ];
    return $map[$domain] ?? 'target';
}
