<?php
/** Site footer and closing markup. */
declare(strict_types=1);

if (!defined('APP_ROOT')) {
    exit('Direct access is not permitted.');
}
?>
</main>

<footer class="site-footer">
  <div class="footer-main">
    <div class="container">
      <div class="footer-grid">

        <div class="footer-brand">
          <a class="brand" href="<?= e(url('/')) ?>">
            <img class="brand-mark" src="<?= e(url('/assets/img/logo-light.svg')) ?>" alt="" width="38" height="38">
            <span class="brand-text">
              <span class="brand-name"><?= e($SITE['short']) ?></span>
              <span class="brand-sub">Research</span>
            </span>
          </a>
          <p><?= e($SITE['intro']) ?></p>
          <div class="social-row" style="margin-top:22px;">
            <?php foreach ($SITE['social'] as $item): ?>
              <a href="<?= e($item['url']) ?>" target="_blank" rel="noopener"><?= e($item['label']) ?></a>
            <?php endforeach; ?>
          </div>
        </div>

        <div>
          <h3>Explore</h3>
          <ul class="footer-links">
            <li><a href="<?= e(url('/research/')) ?>">Research domains</a></li>
            <li><a href="<?= e(url('/team/researchers/')) ?>">Researchers</a></li>
            <li><a href="<?= e(url('/team/scholars/')) ?>">Wall of Scholars</a></li>
            <li><a href="<?= e(url('/publications/journal/')) ?>">Journal articles</a></li>
            <li><a href="<?= e(url('/publications/conference/')) ?>">Conference papers</a></li>
            <li><a href="<?= e(url('/events/')) ?>">Events &amp; MoUs</a></li>
          </ul>
        </div>

        <div>
          <h3>Resources</h3>
          <ul class="footer-links">
            <li><a href="<?= e(url('/resources/datasets/')) ?>">Datasets</a></li>
            <li><a href="<?= e(url('/resources/github/')) ?>">Code &amp; repositories</a></li>
            <li><a href="<?= e(url('/resources/templates/')) ?>">Writing templates</a></li>
            <li><a href="<?= e(url('/team/collaborators/')) ?>">Collaborators</a></li>
            <li><a href="<?= e(url('/team/committee/')) ?>">Committee</a></li>
            <li><a href="<?= e(url('/join/')) ?>">Join the lab</a></li>
          </ul>
        </div>

        <div>
          <h3>Contact</h3>
          <ul class="footer-contact">
            <li>
              <?= e($SITE['contact']['address']['line1']) ?><br>
              <?= e($SITE['contact']['address']['line2']) ?><br>
              <?= e($SITE['contact']['address']['city']) ?>, <?= e($SITE['contact']['address']['country']) ?>
            </li>
            <li><a href="mailto:<?= e($SITE['contact']['email']) ?>"><?= e($SITE['contact']['email']) ?></a></li>
            <li><a href="tel:<?= e(str_replace(' ', '', $SITE['contact']['phone'])) ?>"><?= e($SITE['contact']['phone']) ?></a></li>
            <li><?= e($SITE['contact']['hours']) ?></li>
          </ul>
        </div>

      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <div class="container">
      <span>&copy; <?= date('Y') ?> <?= e($SITE['name']) ?>. All rights reserved.</span>
      <span>Established <?= e((string) $SITE['founded']) ?> · Dhaka, Bangladesh · <a href="<?= e(url('/contact/')) ?>">Contact</a></span>
    </div>
  </div>
</footer>

<script src="<?= e(url('/assets/js/main.js')) ?>" defer></script>
</body>
</html>
