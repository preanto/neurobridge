<?php
/**
 * Site head, top bar, masthead and primary navigation.
 *
 * Pages may define before including this file:
 *   $page_title       — browser title (without the site name)
 *   $page_description — meta description
 */

declare(strict_types=1);

if (!defined('APP_ROOT')) {
    exit('Direct access is not permitted.');
}

$page_title       = $page_title       ?? '';
$page_description = $page_description ?? $SITE['meta_description'];
$full_title       = $page_title !== ''
    ? $page_title . ' — ' . $SITE['name']
    : $SITE['name'] . ' — ' . $SITE['tagline'];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($full_title) ?></title>
<meta name="description" content="<?= e($page_description) ?>">
<meta name="theme-color" content="#0f6b73">
<meta property="og:site_name" content="<?= e($SITE['name']) ?>">
<meta property="og:title" content="<?= e($full_title) ?>">
<meta property="og:description" content="<?= e($page_description) ?>">
<meta property="og:type" content="website">
<link rel="icon" href="<?= e(url('/assets/img/favicon.svg')) ?>" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(url('/assets/css/style.css') . '?v=' . (@filemtime(APP_ROOT . '/assets/css/style.css') ?: 1)) ?>">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<div class="topbar">
  <div class="container">
    <div class="topbar-list">
      <span><?= icon('mail', 'ico') ?><a href="mailto:<?= e($SITE['contact']['email']) ?>"><?= e($SITE['contact']['email']) ?></a></span>
      <span class="topbar-list--hide-sm"><?= icon('pin', 'ico') ?><?= e($SITE['contact']['address']['city']) ?>, <?= e($SITE['contact']['address']['country']) ?></span>
    </div>
    <div class="topbar-list topbar-list--hide-sm">
      <?php foreach (array_slice($SITE['social'], 0, 3) as $item): ?>
        <a href="<?= e($item['url']) ?>" target="_blank" rel="noopener"><?= e($item['label']) ?></a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<header class="site-header">
  <div class="container">
    <a class="brand" href="<?= e(url('/')) ?>">
      <img class="brand-mark" src="<?= e(url('/assets/img/logo.svg')) ?>" alt="" width="38" height="38">
      <span class="brand-text">
        <span class="brand-name"><?= e($SITE['short']) ?></span>
        <span class="brand-sub">Research</span>
      </span>
    </a>

    <nav class="nav" aria-label="Primary">
      <?php foreach ($NAV as $item): ?>
        <?php $hasChildren = !empty($item['children']); ?>
        <div class="nav-item">
          <a class="nav-link<?= is_active($item['path'], $hasChildren) ? ' is-active' : '' ?>" href="<?= e(url($item['path'])) ?>">
            <?= e($item['label']) ?>
            <?php if ($hasChildren): ?>
              <svg class="nav-caret" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5"/></svg>
            <?php endif; ?>
          </a>
          <?php if ($hasChildren): ?>
            <div class="nav-dropdown">
              <?php foreach ($item['children'] as $child): ?>
                <a class="<?= is_active($child['path']) ? 'is-active' : '' ?>" href="<?= e(url($child['path'])) ?>"><?= e($child['label']) ?></a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </nav>

    <div class="header-cta">
      <a class="btn btn-primary btn-sm" href="<?= e(url('/join/')) ?>">Join the lab</a>
      <button class="nav-toggle" type="button" id="navToggle" aria-expanded="false" aria-controls="mobileNav" aria-label="Toggle navigation">
        <span></span>
      </button>
    </div>
  </div>

  <div class="mobile-nav" id="mobileNav">
    <div class="container">
      <ul>
        <?php foreach ($NAV as $item): ?>
          <li>
            <a class="<?= is_active($item['path'], !empty($item['children'])) ? 'is-active' : '' ?>" href="<?= e(url($item['path'])) ?>"><?= e($item['label']) ?></a>
          </li>
          <?php if (!empty($item['children'])): ?>
            <?php foreach ($item['children'] as $child): ?>
              <li class="sub"><a class="<?= is_active($child['path']) ? 'is-active' : '' ?>" href="<?= e(url($child['path'])) ?>"><?= e($child['label']) ?></a></li>
            <?php endforeach; ?>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul>
      <a class="btn btn-primary btn-block" href="<?= e(url('/join/')) ?>">Join the lab</a>
    </div>
  </div>
</header>

<main id="main">
