<?php
/**
 * Shared helper functions.
 */

declare(strict_types=1);

/** Escape a string for safe HTML output. */
function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Build an absolute URL for an internal path. */
function url(string $path = '/'): string
{
    if (preg_match('#^(https?:)?//#i', $path) || str_starts_with($path, 'mailto:') || str_starts_with($path, 'tel:')) {
        return $path;
    }
    return BASE_URL . '/' . ltrim($path, '/');
}

/** Current request path, normalised with a leading and trailing slash. */
function current_path(): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    if (BASE_URL !== '' && str_starts_with($path, BASE_URL)) {
        $path = substr($path, strlen(BASE_URL));
    }
    $path = '/' . trim($path, '/');
    $path = preg_replace('#/index\.php$#', '/', $path) ?? $path;
    return rtrim($path, '/') . '/';
}

/** True when $path is the current page (or a parent section of it). */
function is_active(string $path, bool $section = false): bool
{
    $current = current_path();
    $path    = rtrim($path, '/') . '/';

    if ($path === '/') {
        return $current === '/';
    }
    return $section ? str_starts_with($current, $path) : $current === $path;
}

/** Two-letter initials used for the avatar placeholders. */
function initials(string $name): string
{
    $name  = trim(preg_replace('/^(Prof\.|Dr\.|Mr\.|Ms\.|Mrs\.|Engr\.)\s+/i', '', $name) ?? $name);
    $parts = preg_split('/\s+/', $name) ?: [];
    $parts = array_values(array_filter($parts));

    if (count($parts) === 0) {
        return '—';
    }
    if (count($parts) === 1) {
        return strtoupper(mb_substr($parts[0], 0, 2));
    }
    return strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[count($parts) - 1], 0, 1));
}

/** Deterministic tint (1–6) so each avatar keeps the same colour on every page. */
function avatar_tone(string $seed): int
{
    return (crc32($seed) % 6) + 1;
}

/** Render a list of small badges. */
function badges(array $items, string $variant = ''): string
{
    if (!$items) {
        return '';
    }
    $class = trim('badge ' . $variant);
    $html  = '<span class="badge-group">';
    foreach ($items as $item) {
        $html .= '<span class="' . e($class) . '">' . e((string) $item) . '</span>';
    }
    return $html . '</span>';
}

/** CSRF token for the current session. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

function csrf_valid(?string $token): bool
{
    return is_string($token) && !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

/** Trimmed POST value. */
function post(string $key, string $default = ''): string
{
    $value = $_POST[$key] ?? $default;
    return is_string($value) ? trim($value) : $default;
}

/** Trimmed GET value. */
function query(string $key, string $default = ''): string
{
    $value = $_GET[$key] ?? $default;
    return is_string($value) ? trim($value) : $default;
}

/**
 * Persist a form submission as JSON under /storage/submissions/
 * and optionally send an e-mail notification.
 */
function store_submission(string $type, array $data): bool
{
    if (!is_dir(STORAGE_PATH) && !@mkdir(STORAGE_PATH, 0775, true) && !is_dir(STORAGE_PATH)) {
        return false;
    }

    $record = [
        'type'       => $type,
        'received'   => date('c'),
        'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',
        'user_agent' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        'fields'     => $data,
    ];

    $file  = STORAGE_PATH . '/' . $type . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.json';
    $bytes = @file_put_contents($file, json_encode($record, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

    if (MAIL_NOTIFY) {
        $lines = [];
        foreach ($data as $key => $value) {
            $lines[] = ucwords(str_replace('_', ' ', (string) $key)) . ': ' . (is_array($value) ? implode(', ', $value) : $value);
        }
        @mail(
            MAIL_TO,
            'Neurobridge website — new ' . $type . ' submission',
            implode("\n", $lines),
            'Content-Type: text/plain; charset=UTF-8'
        );
    }

    return $bytes !== false;
}

/** Simple e-mail check. */
function valid_email(string $email): bool
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

/** Unique, sorted list of values pulled from a column of rows. */
function column_options(array $rows, string $key, bool $descending = false): array
{
    $values = [];
    foreach ($rows as $row) {
        $value = $row[$key] ?? null;
        foreach ((array) $value as $item) {
            if ($item !== null && $item !== '') {
                $values[(string) $item] = true;
            }
        }
    }
    // array_keys() turns numeric keys back into integers — cast them back so
    // callers always receive strings (years, counts, etc.).
    $values = array_map('strval', array_keys($values));
    $descending ? rsort($values, SORT_NATURAL) : sort($values, SORT_NATURAL);
    return $values;
}

/** Rebuild the current query string with one parameter replaced. */
function query_with(array $params): string
{
    $merged = array_merge($_GET, $params);
    $merged = array_filter($merged, static fn ($v) => $v !== '' && $v !== null);
    return $merged ? '?' . http_build_query($merged) : '';
}

/** Convert **Name** markers in an author string into bold lab-member names. */
function authors_html(string $authors): string
{
    $escaped = e($authors);
    return preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $escaped) ?? $escaped;
}

/** Badge colour for an indexing label. */
function index_badge_class(string $label): string
{
    $map = [
        'Q1'            => 'badge--accent',
        'Q2'            => 'badge--outline',
        'Scopus'        => 'badge--brand',
        'SCIE'          => 'badge--brand',
        'ESCI'          => 'badge--outline',
        'PubMed'        => 'badge--outline',
        'Open Access'   => 'badge--ok',
        'IEEE Xplore'   => 'badge--brand',
        'Springer LNCS' => 'badge--brand',
        'AIP'           => 'badge--brand',
        'DBLP'          => 'badge--outline',
        'Web of Science CPCI' => 'badge--brand',
        'Conference Abstract' => 'badge--outline',
    ];
    return $map[$label] ?? '';
}

/**
 * Render one publication entry.
 * $kind is 'journal' or 'conference'.
 */
function publication_item(array $p, string $kind = 'journal'): string
{
    $link = $p['url'] ?? '';
    if ($link === '' && !empty($p['doi'])) {
        $link = 'https://doi.org/' . $p['doi'];
    }

    $title = e($p['title']);
    if ($link !== '') {
        $title = '<a href="' . e($link) . '" target="_blank" rel="noopener">' . $title . '</a>';
    }

    $venueLine = '<em>' . e($p['venue']) . '</em>';
    if (!empty($p['detail'])) {
        $venueLine .= ' · ' . e($p['detail']);
    }
    if (!empty($p['location'])) {
        $venueLine .= ' · ' . e($p['location']);
    }
    if (!empty($p['date'])) {
        $venueLine .= ' · ' . e($p['date']);
    }

    $badgesHtml = '';
    foreach ($p['indexes'] ?? [] as $label) {
        $badgesHtml .= '<span class="badge ' . index_badge_class((string) $label) . '">' . e((string) $label) . '</span>';
    }

    $doiHtml = '';
    if (!empty($p['doi'])) {
        $doiHtml = '<a class="pub-doi" href="https://doi.org/' . e($p['doi']) . '" target="_blank" rel="noopener">DOI: ' . e($p['doi']) . '</a>';
    }

    $typeLabel = $kind === 'conference' ? ($p['type'] ?? 'Conference') : 'Journal';

    return '<li class="pub-item" data-filter-item>'
        . '<div class="pub-year">' . e((string) $p['year']) . '<span class="pub-type">' . e($typeLabel) . '</span></div>'
        . '<div>'
        . '<h3 class="pub-title">' . $title . '</h3>'
        . '<p class="pub-authors">' . authors_html((string) ($p['authors'] ?? '')) . '</p>'
        . '<p class="pub-venue">' . $venueLine . '</p>'
        . '<div class="pub-foot"><span class="badge-group">' . $badgesHtml . '</span>' . $doiHtml . '</div>'
        . '</div></li>';
}

/** Filter a publication list by year, index label, domain and free-text search. */
function filter_publications(array $rows, string $year = '', string $index = '', string $domain = '', string $search = ''): array
{
    $search = mb_strtolower($search);

    return array_values(array_filter($rows, static function (array $row) use ($year, $index, $domain, $search): bool {
        if ($year !== '' && (string) $row['year'] !== $year) {
            return false;
        }
        if ($index !== '' && !in_array($index, $row['indexes'] ?? [], true)) {
            return false;
        }
        if ($domain !== '' && !in_array($domain, $row['domains'] ?? [], true)) {
            return false;
        }
        if ($search !== '') {
            $haystack = mb_strtolower(
                ($row['title'] ?? '') . ' ' . ($row['authors'] ?? '') . ' ' . ($row['venue'] ?? '')
            );
            if (mb_strpos($haystack, $search) === false) {
                return false;
            }
        }
        return true;
    }));
}

/** Render an avatar circle for a person. */
function avatar(string $name, string $size = ''): string
{
    $class = trim('avatar tone-' . avatar_tone($name) . ' ' . $size);
    return '<span class="' . e($class) . '" aria-hidden="true">' . e(initials($name)) . '</span>';
}

/**
 * Render a person photo next to their name, falling back to the initials
 * avatar when no photo is set or the file has not been uploaded yet.
 * Add a 'photo' key (e.g. '/assets/img/team/name.jpg') to a person's record.
 */
function person_photo(array $person, string $size = ''): string
{
    $photo = $person['photo'] ?? '';
    $name  = (string) ($person['name'] ?? '');

    if ($photo !== '' && file_exists(APP_ROOT . $photo)) {
        $class = trim('avatar person-photo ' . $size);
        $src   = url($photo) . '?v=' . @filemtime(APP_ROOT . $photo);
        return '<img class="' . e($class) . '" src="' . e($src) . '" alt="' . e($name) . '" loading="lazy">';
    }
    return avatar($name, $size);
}

/** Labelled external links shown on a person card. */
function person_links(array $links): string
{
    if (!$links) {
        return '';
    }
    $labels = [
        'email'    => 'Email',
        'scholar'  => 'Scholar',
        'orcid'    => 'ORCID',
        'linkedin' => 'LinkedIn',
        'github'   => 'GitHub',
        'website'  => 'Website',
    ];

    $html = '<div class="person-links">';
    foreach ($links as $key => $value) {
        if ($value === '' || $value === null) {
            continue;
        }
        $href = $key === 'email' ? 'mailto:' . $value : $value;
        $rel  = $key === 'email' ? '' : ' target="_blank" rel="noopener"';
        $html .= '<a href="' . e($href) . '"' . $rel . '>' . e($labels[$key] ?? ucfirst((string) $key)) . '</a>';
    }
    return $html . '</div>';
}

/** Number formatted for the impact counters (e.g. 120 -> "120+"). */
function metric(int $value, string $suffix = '+'): string
{
    return number_format($value) . $suffix;
}
