<?php
/**
 * Neurobridge Research — application bootstrap.
 * Every page includes this file first.
 */

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('APP_ROOT', dirname(__DIR__));

require_once APP_ROOT . '/includes/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/includes/icons.php';

// Content -------------------------------------------------------------------
$SITE         = require APP_ROOT . '/includes/data/site.php';
$RESEARCH     = require APP_ROOT . '/includes/data/research.php';
$TEAM         = require APP_ROOT . '/includes/data/team.php';
$PUBLICATIONS = require APP_ROOT . '/includes/data/publications.php';
$EVENTS       = require APP_ROOT . '/includes/data/events.php';
$RESOURCES    = require APP_ROOT . '/includes/data/resources.php';
$NEWS         = require APP_ROOT . '/includes/data/news.php';
